# Pack review and corrections

The authoring host reviewed the retained Full Skill manuscript against archive fields, estimates, the NOAA texts and the figure. This review is within one authorship context. Parent-agent review is separate.

1. Critical count mismatch, Abstract. On June 29, the `results.json` daily departures show four Lake groups above threshold and three Atlantic groups above threshold. The draft switched these denominators. The Pack draft now reports the combined 7/8, and Web revision addresses the corridor breakdown with named groups.
2. Peak support, Results. The first draft compared peak spans using the early core window despite defining peaks over the larger neighborhoods. The revised result describes the chronological overlap directly. The map/heatmap retains Milwaukee's June 4 peak within the early neighborhood.
3. Late event context, Discussion. Keep NOAA forecast and surface monitor interpretation distinct. The late NOAA ARL account establishes the Great Lakes/eastern Ohio event context; we narrowed the revised sentence accordingly.
4. Unit and study scope. Departure threshold operates on local reference differences. Omission ranges describe sensitivity of the two finite-period contrasts, not sampling intervals. Completeness leaves out Buffalo and Baltimore entirely and reduces the New York grouping to two sites.
5. Presentation. Increased body size to 11 pt and line spacing in source. Kept the map separate from anomaly magnitude and an explicit common color scale.
