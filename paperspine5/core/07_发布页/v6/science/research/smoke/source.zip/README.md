# June smoke, two different footprints

A descriptive monitor-panel analysis of two June 2023 Canadian wildfire smoke episodes. The Atlantic-minus-Great-Lakes contrast changed from +74.1 µg/m³ (June 6–8) to −69.1 µg/m³ (June 27–29), using local reference medians from June 20–22. Seven of eight county groups were at least 20 µg/m³ above reference on June 29, after the four Great Lakes group peaks.

## Read and reproduce

- `paper.pdf` and `main.tex` are the reading and editable papers. The TeX source requires `figure.pdf`.
- `figure.svg` and `figure.webp` are editorial assets. `plot.py` regenerates them from `results.json` and the Natural Earth subset in `map_shapes.json`.
- `results.json` includes the 810 retained site-days, the site and county relationships, counts, references, contrasts and sensitivities. `protocol.md` records the design fixed before looking at concentrations.

Retrieve the original `daily_88101_2023.zip` from [EPA AirData](https://aqs.epa.gov/aqsweb/airdata/daily_88101_2023.zip). The SHA-256 for this 9,919,616-byte snapshot is `4b40502e8147419643a1120c666c4aa952633094f21f65475844172bcc78833b`. The raw archive stays outside this package. Later revisions to the EPA archive can change its hash and the script will stop. Plot context uses the public-domain 1:50m [Natural Earth polygons](https://www.naturalearthdata.com/about/terms-of-use/).

```text
python -B analyze.py /path/to/daily_88101_2023.zip
python -B plot.py
xelatex -interaction=nonstopmode -halt-on-error -jobname=paper main.tex
xelatex -interaction=nonstopmode -halt-on-error -jobname=paper main.tex
```

Matplotlib 3.10.9, NumPy 2.2.6, Pillow 12.2.0 and TeX Live 2025 generated these outputs. Both PDF and SVG preserve figure text and mapped coordinates. Core estimates and location labels describe a finite panel of county groups. NOAA evidence contextualizes the events, and AQS concentration data are total ambient PM₂.₅.
