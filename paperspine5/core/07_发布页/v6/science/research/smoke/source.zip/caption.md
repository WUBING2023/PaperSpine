# Urban departures across two June smoke episodes

**A.** Actual locations of 27 EPA AQS PM₂.₅ sites with the same instrument stream throughout June 2023, grouped into four Great Lakes and four Atlantic urban county groups. **B.** Atlantic-minus-Lake mean departure contrasts across June 6–8 and 27–29. Dots and ticks show results after individually omitting sites and county groups, respectively. **C.** Urban-group median departures by local day, calculated after subtracting each site's June 20–22 median. The filled dots mark the earliest peak in the June 4–10 or June 25–30 neighborhood. The upper color extension covers values above 150 µg/m³.

The Atlantic corridor had departures 74.1 µg/m³ higher in the early core window, while the Great Lakes corridor had departures 69.1 µg/m³ higher in the late core window. Those are descriptive contrasts for the sampled monitor panel. NOAA event records provide context.
