# Reference-guided revision

The installed research stage checked the full-month panel, numeric audit, and documented event windows against the unchanged AQS archive. The Pack reuses the Full Skill's empirical work. These two stages are part of one study.

Cooper et al. (2024), GEOphysical Research Letters article e2024GL111481, p. 2, Methods ¶2, first specifies treatment of missing hourly observations and then handles multiple PM instruments at a site. Our Methods makes the equivalent two selection decisions explicit. It chooses a single stable physical-site instrument stream over June and uses within-group medians, serving a different longitudinal comparison. The EPA archive fields are the governing source.

Cooper et al., p. 3, Results ¶2–3 and Figure 2 presents dated regional maps before interpreting pollution patterns. Figure 1 here puts actual site locations next to the time-resolved group values and contrast, retaining separate geographic context and measured results. No reference figure marks or quantitative values were reused.

Cooper et al., p. 1, Introduction final paragraph, sets out the particular temporal and geographic scope before stating the result's significance. The initial paper's Discussion said the fixed panel “adds a common daily comparison.” The revised passage specifies the three empirical questions that accounting choice resolves: “which corridor had larger typical departures, when groups peaked, and when their departures overlapped.” The common site panel and Table 1 substantiate these distinctions. The paper's organization retains its own focus on synchrony in bulk PM₂.₅.

Primary source: https://repository.library.noaa.gov/view/noaa/67968/noaa_67968_DS1.pdf
