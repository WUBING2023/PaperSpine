from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
from pathlib import Path
from statistics import median, mean
import sys
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
HASH = '4b40502e8147419643a1120c666c4aa952633094f21f65475844172bcc78833b'
GROUPS = {
    'Milwaukee': ('Lake', ['55-079']), 'Chicago': ('Lake', ['17-031']),
    'Detroit': ('Lake', ['26-163']), 'Cleveland': ('Lake', ['39-035']),
    'Buffalo': ('Lake', ['36-029']), 'Boston': ('Atlantic', ['25-025']),
    'New York': ('Atlantic', ['36-005','36-047','36-061','36-081','36-085']),
    'Philadelphia': ('Atlantic', ['42-101']), 'Baltimore': ('Atlantic', ['24-510']),
    'Washington': ('Atlantic', ['11-001']),
}
COUNTIES = {county: group for group, (_, counties) in GROUPS.items() for county in counties}
DAYS = list(range(1,31))
WINDOWS = [([6,7,8], list(range(4,11))), ([27,28,29], list(range(25,31)))]


def load(archive):
    with archive.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if digest != HASH:
        raise ValueError('The retrieved archives differ from the analysis freeze: ' + digest)
    candidates = defaultdict(lambda: defaultdict(dict))
    ledger = Counter()
    with ZipFile(archive) as release, release.open('daily_88101_2023.csv') as binary:
        for row in csv.DictReader(io.TextIOWrapper(binary, encoding='utf-8-sig')):
            group = COUNTIES.get('-'.join([row['State Code'], row['County Code']]))
            date = row['Date Local']
            if not group or not date.startswith('2023-06-'):
                continue
            ledger['June rows in the county groups'] += 1
            duration = row['Sample Duration']
            if (duration not in ('24-HR BLK AVG', '24 HOUR') or
                row['Pollutant Standard'] != 'PM25 24-hour 2012' or
                row['Parameter Code'] != '88101' or
                row['Units of Measure'] != 'Micrograms/cubic meter (LC)'):
                continue
            ledger['Canonical 24-hour rows before event and coverage filtering'] += 1
            if row['Event Type'] not in ('Included','None'):
                ledger['Event-filtered summary rows'] += 1
                continue
            coverage = float(row['Observation Percent'])
            count = int(row['Observation Count'])
            if coverage < (75 if duration == '24-HR BLK AVG' else 100) or not count:
                ledger['Coverage-filtered summary rows'] += 1
                continue
            sid = '-'.join([row['State Code'], row['County Code'], row['Site Num']])
            key = (duration, int(row['POC']), row['Method Code'])
            day = int(date[-2:])
            value = (float(row['Arithmetic Mean']), float(row['Longitude']), float(row['Latitude']), row['Datum'])
            score = (coverage, count, row['Event Type'] == 'Included')
            old = candidates[sid][key].get(day)
            if old:
                ledger['Repeated rows within the same stream-day'] += 1
                if score == old[0] and value != old[1]:
                    raise ValueError((sid,key,day,old,value))
            if old is None or score > old[0]:
                candidates[sid][key][day] = (score,value)
    ledger['Eligible physical sites before June completeness'] = len(candidates)
    sites = {}
    for sid, instruments in candidates.items():
        complete = [key for key, rows in instruments.items() if set(rows) == set(DAYS)]
        if not complete:
            continue
        key = min(complete, key=lambda k: (k[0] != '24-HR BLK AVG',
                    -sum(s[0][0] for s in instruments[k].values()), k[1], k[2]))
        rows = instruments[key]
        xy = {r[1][1:] for r in rows.values()}
        if len(xy) != 1:
            raise ValueError(('Moving monitor',sid,xy))
        lon, lat, datum = xy.pop()
        sites[sid] = {'group': COUNTIES[sid.rsplit('-',1)[0]], 'lon': lon, 'lat': lat,
                      'datum': datum, 'duration': key[0], 'poc': key[1], 'method': key[2],
                      'days': [rows[day][1][0] for day in DAYS]}
    return sites, ledger


def longest(values, threshold):
    streak = best = 0
    for value in values:
        streak = streak + 1 if value >= threshold else 0
        best = max(streak, best)
    return best


def estimate(sites, reference=(20,21,22)):
    baseline = {sid: median(site['days'][day-1] for day in reference) for sid,site in sites.items()}
    values = defaultdict(list)
    for sid, site in sites.items():
        values[site['group']].append([value-baseline[sid] for value in site['days']])
    daily = {group: list(map(median,zip(*arrays))) for group,arrays in values.items()}
    corridor = {region: list(map(median,zip(*[daily[group] for group in daily
                    if GROUPS[group][0] == region]))) for region in ('Lake','Atlantic')}
    epochs = []
    for core, shoulder in WINDOWS:
        level = {region: mean(values[d-1] for d in core) for region,values in corridor.items()}
        peaks = {group: max(shoulder, key=lambda d: trend[d-1]) for group,trend in daily.items()}
        epochs.append({'means': level, 'Atlantic_minus_Lake': level['Atlantic'] - level['Lake'],
                    'peaks': peaks,
                    'longest': {str(t): {group: longest((trend[d-1] for d in shoulder),t)
                        for group,trend in daily.items()} for t in (10,20,30)},
                    'coincident20': {d: sum(v[d-1]>=20 for v in daily.values()) for d in shoulder}})
    return {'reference': reference, 'baseline': baseline, 'cities': daily,
            'corridor': corridor, 'windows': epochs}


def main():
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / 'daily_88101_2023.zip'
    sites, ledger = load(source)
    result = estimate(sites)
    variants = {'alternate_reference': estimate(sites,(1,2,3,23,24,25)),
                'hourly_derived': estimate({s:v for s,v in sites.items() if v['duration']=='24-HR BLK AVG'})}
    for name, omissions in (('leave_site_out', sorted(sites)), ('leave_group_out',list(result['cities']))):
        variants[name] = {key: [w['Atlantic_minus_Lake'] for w in
             estimate({s:v for s,v in sites.items() if s!=key and v['group']!=key})['windows']]
             for key in omissions}
    return dict(sha256=HASH, groups=GROUPS, audit=ledger, sites=sites, primary=result, sensitivity=variants)


if __name__ == '__main__':
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / 'results.json'
    data = main()
    output.write_text(json.dumps(data, indent=2), encoding='utf-8')
    print(len(data['sites']), Counter(v['group'] for v in data['sites'].values()))
    print(json.dumps(data['primary']['windows'], indent=2))
