import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patheffects as effects
import numpy as np
from matplotlib.collections import PolyCollection
from PIL import Image

HERE = Path(__file__).resolve().parent
R = json.loads((HERE / 'results.json').read_text())
P = R['primary']
REGION = {'Lake':'#006782','Atlantic':'#A43C25'}
NAVY, GRAY = '#152B35', '#4B646D'
PAPER = '#FAF9F3'
CMAP = mpl.colors.LinearSegmentedColormap.from_list('anomaly',
    [(0,'#2D6F84'),(.118,'#FCF9EF'),(.29,'#FBE1A7'),(.54,'#E89766'),(1,'#932C29')])
NORM = mpl.colors.Normalize(-20,150)
ORDER = ['Milwaukee','Chicago','Detroit','Cleveland','Boston','New York','Philadelphia','Washington']
mpl.rcParams.update({'font.family':'DejaVu Sans','axes.spines.right':False,
 'axes.spines.top':False,'axes.labelcolor':NAVY,'xtick.color':GRAY,'ytick.color':GRAY,
 'text.color':NAVY,'axes.edgecolor':'#A8B5B1','figure.facecolor':PAPER,'axes.facecolor':PAPER,
 'svg.fonttype':'none','pdf.fonttype':42,'font.size':11})


def geography():
    source = [('ne_countries.geojson','land'),('ne_lakes.geojson','water')]
    extent = (-90,-69,36.8,47.0)
    for name, layer in source:
        data = json.loads((HERE/name).read_text(encoding='utf-8'))
        for feature in data['features']:
            geom = feature['geometry']
            polygons = geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']]
            for polygon in polygons:
                coords = polygon[0]
                x,y = zip(*coords)
                if min(x)<extent[1] and max(x)>extent[0] and min(y)<extent[3] and max(y)>extent[2]:
                    yield layer, coords


def map_panel(ax, shapes):
    colors = {'land':('#E9E9D9','#ADB8AC'),'water':('#DBEAE9','#ACBEBD')}
    ax.set_facecolor('#DBEAE9')
    for layer in colors:
        fill, edge = colors[layer]
        ax.add_collection(PolyCollection([xy for name,xy in shapes if name==layer],
                        facecolors=fill,edgecolors=edge,linewidths=.5))
    ax.set(xlim=(-89,-69.2),ylim=(37.4,46.0),xticks=[],yticks=[])
    ax.set_aspect(1.35)
    ax.text(-82.4,44.9,'CANADA',fontsize=9,ha='center',color='#6A827D',weight='bold')
    ax.text(-85,39.1,'UNITED STATES',fontsize=9,ha='center',color='#6A827D',weight='bold')
    ax.text(-73,38.05,'Atlantic Ocean',fontsize=7,ha='center',color=GRAY,style='italic')
    offsets = {'Milwaukee':(-.28,.65),'Chicago':(-.25,-.53),'Detroit':(-.2,.65),
          'Cleveland':(.20,-.58),'Boston':(.1,.65),'New York':(.64,-.15),
          'Philadelphia':(-1.02,.75),'Washington':(-.46,-.63)}
    for group in ORDER:
        sites=[v for v in R['sites'].values() if v['group']==group]
        x=[v['lon'] for v in sites]
        y=[v['lat'] for v in sites]
        color=REGION[R['groups'][group][0]]
        ax.scatter(x,y,s=24,c=color,edgecolors=PAPER,linewidths=.45,zorder=5)
        dx,dy=offsets[group]
        x0,y0=np.mean(x),np.mean(y)
        ax.annotate(group,(x0,y0),(x0+dx,y0+dy),fontsize=8.5,weight='bold',color=color,
              ha='left' if dx>0 else 'right',va='center',
              path_effects=[effects.withStroke(linewidth=2, foreground=PAPER)],
              arrowprops={'arrowstyle':'-','color':color,'lw':.55},zorder=7)


def main():
    shapes = list(geography())
    (HERE/'map_shapes.json').write_text(json.dumps(shapes,separators=(',',':')),encoding='utf-8')
    draw(shapes)


def draw(shapes):
    fig = plt.figure(figsize=(10.8,9.2))
    fig.text(.065,.946,'June smoke, two different footprints',font='DejaVu Serif',fontsize=29,weight='bold')
    fig.text(.065,.91,'PM₂.₅ departures across eight urban county groups · June 2023',fontsize=13,color=GRAY)
    mp=fig.add_axes([.065,.565,.475,.292])
    mp.set_title('A   Fixed monitoring sites',loc='left',fontweight='bold',pad=10)
    map_panel(mp,shapes)
    c=fig.add_axes([.622,.60,.319,.226])
    c.set_title('B   The corridor contrast reverses',loc='left',fontweight='bold',pad=15)
    c.axvline(0,color=GRAY,lw=.8)
    for idx,window in enumerate(P['windows']):
        for kind,marker in [('leave_site_out','.'),('leave_group_out','|')]:
            x=[v[idx] for v in R['sensitivity'][kind].values()]
            c.scatter(x,np.full(len(x),1-idx)+(.105 if marker=='.' else -.105),s=38,
                      alpha=.5,marker=marker,c='#709293',zorder=3)
        delta=window['Atlantic_minus_Lake']
        cor=list(REGION.values())[delta>0]
        c.plot([0,delta],[1-idx]*2,lw=3,color=cor,zorder=3,solid_capstyle='round')
        c.scatter(delta,1-idx,s=79,c=cor,edgecolors=PAPER,lw=.85,zorder=5)
        rounded = Decimal(str(delta)).quantize(Decimal('0.1'), rounding=ROUND_HALF_UP)
        c.text(delta,1-idx+.19,f'{rounded:+.1f}',c=cor,weight='bold',ha='center')
    c.set(xlim=(-108,108),ylim=(-.38,1.43),yticks=[0,1],yticklabels=['27–29','6–8'],
          xticks=[-100,-50,0,50,100],xlabel='Atlantic minus Lake · µg/m³')
    c.tick_params(axis='y',length=0)
    c.spines['left'].set_visible(False)
    fig.text(.622,.52,'Sensitivities · dots omit a site; ticks omit a city',color=GRAY,fontsize=9)
    h=fig.add_axes([.195,.23,.745,.229])
    h.set_title('C   Urban groups peaked on different days',loc='left',fontweight='bold',pad=28)
    values=[[P['cities'][group][d-1] for d in range(1,31)] for group in ORDER]
    h.imshow(values,aspect='auto',cmap=CMAP,norm=NORM,extent=(.5,30.5,7.5,-.5),interpolation='nearest')
    for day in np.arange(.5,31,.999999):
        h.axvline(day,color=PAPER,alpha=.84,lw=.42)
    for y in np.arange(-.5,8,.999999):
        h.axhline(y,color=PAPER,alpha=.9,lw=.65)
    h.axhline(3.5,color=NAVY,lw=1.8)
    for idx,group in enumerate(ORDER):
        for w in P['windows']:
            day=w['peaks'][group]
            h.scatter(day,idx,s=21,c=NAVY,edgecolors=PAPER,lw=.6,zorder=5)
    for l,r,title,col in [(6,8,'EARLY',REGION['Atlantic']),(20,22,'REFERENCE',GRAY),(27,29,'LATE',REGION['Lake'])]:
        h.plot([l-.43,r+.43],[-.87]*2,color=col,lw=2,clip_on=False)
        h.text((l+r)/2,-1.05,title,ha='center',va='bottom',color=col,fontsize=8.1,weight='bold',clip_on=False)
    h.set(xticks=[1,5,10,15,20,25,30],yticks=range(8),yticklabels=ORDER)
    h.tick_params(length=0)
    for label,g in zip(h.get_yticklabels(),ORDER):
        label.set_color(REGION[R['groups'][g][0]])
        label.set_weight('bold')
    h.spines[['left','bottom']].set_visible(False)
    h.set_xlabel('June day (local)',labelpad=6)
    cb=fig.add_axes([.195,.116,.365,.021])
    bar=fig.colorbar(mpl.cm.ScalarMappable(cmap=CMAP,norm=NORM),cax=cb,orientation='horizontal',
          ticks=[-20,0,20,50,100,150],extend='max')
    bar.outline.set_visible(False)
    bar.ax.tick_params(size=2,labelsize=9)
    fig.text(.195,.149,'Departure from local reference · µg/m³',fontsize=9,color=GRAY)
    fig.text(.631,.129,'●  Group peak inside each event neighborhood',fontsize=9,color=GRAY)
    fig.text(.065,.041,'EPA AirData AQS 88101 · 27 physical sites · 30 local days',fontsize=9,color=GRAY)
    for ext in ['svg','pdf','png']:
        fig.savefig(HERE/f'figure.{ext}',dpi=204)
    img=Image.open(HERE/'figure.png').convert('RGB')
    img.save(HERE/'figure.webp',quality=93,method=6)
    img.thumbnail((350,350),Image.Resampling.LANCZOS)
    img.save(HERE/'thumb.png')


if __name__ == '__main__':
    if all((HERE/name).exists() for name in ('ne_countries.geojson','ne_lakes.geojson')):
        main()
    else:
        draw(json.loads((HERE/'map_shapes.json').read_text()))
