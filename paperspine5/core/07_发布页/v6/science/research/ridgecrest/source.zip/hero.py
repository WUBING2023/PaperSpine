from pathlib import Path
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

from figures import DATA, DARK, BLUE, ORANGE, GREY, items, ROOT, mpl

f=plt.figure(figsize=(10,6.25),facecolor='#fbfcfc')
f.text(.072,.913,'Two catalogs, two apparent decay rates',fontsize=24,fontweight='bold')
f.text(.073,.853,'2019 RIDGECREST   /   COMCAT AND SHELLY RELOCATED',fontsize=10,
       fontweight='bold',color=GREY)
ax=f.add_axes([.09,.17,.54,.57])
ax.set_facecolor('#fbfcfc')
edges=np.array(DATA['bins'])
center=np.sqrt(edges[:-1]*edges[1:])
ax.axvspan(72,216,color='#e8eff0',lw=0)
ax.axvline(1,color='#96a6ae',ls=':',lw=1)
ax.axvline(72,color='#96a6ae',ls=':',lw=1)
for index,(item,color,mark) in enumerate(zip(items,[ORANGE,BLUE],['o','s'])):
    fit=item['fits'][1][1]
    ax.plot(center,np.array(item['time_bins'])/np.diff(edges),marker=mark,ls='none',
            mfc='white',mec=color,color=color,ms=4.8,zorder=3)
    for j,xx in enumerate([np.geomspace(1,72,100),np.geomspace(72,216,60)]):
        ax.plot(xx,fit['amplitude']/xx**fit['p'],color=color,lw=2,ls='-' if j==0 else '--')
ax.set(xscale='log',yscale='log',xlim=(.25,216),ylim=(9,600),
       xlabel='Hours after the Mw 7.1 mainshock',ylabel='Recorded events per hour')
ax.set_xticks([.25,1,6,24,72,216],['¼','1','6','24','72','216'])
ax.set_yticks([10,30,100,300],['10','30','100','300'])
ax.grid(axis='y',color='#dce3e5')
ax.set_axisbelow(True)
ax.text(123,385,'Held',ha='center',color=GREY,fontsize=8)
f.add_artist(plt.Line2D([.67,.67],[.19,.73],transform=f.transFigure,color='#dce3e5',lw=1))
f.text(.71,.71,'FITTED DECAY EXPONENT',color=GREY,fontweight='bold',fontsize=10)
f.text(.71,.61,'0.550',fontsize=32,fontweight='bold',color=ORANGE)
f.text(.712,.564,'ComCat',fontsize=11,color=DARK)
f.text(.71,.456,'0.481',fontsize=32,fontweight='bold',color=BLUE)
f.text(.712,.405,'Shelly relocated',fontsize=11,color=DARK)
f.text(.712,.30,'M ≥ 1.5 in both datasets\nFit to hours 1–72',fontsize=11,color=GREY,linespacing=1.5)
f.text(.072,.060,'Data: USGS ComCat and Shelly (2020), USGS data release 10.5066/P9JN6H0N',color=GREY,fontsize=8.7)
f.savefig(ROOT/'hero-preview.png',dpi=200,facecolor=f.get_facecolor())
f.savefig(ROOT/'hero.svg',facecolor=f.get_facecolor())
with Image.open(ROOT/'hero-preview.png') as im:
    im.convert('RGB').save(ROOT/'hero.webp',quality=95,method=6)
