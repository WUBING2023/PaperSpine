from __future__ import annotations

import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, LogNorm
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter
import numpy as np
from PIL import Image

from analyze import ROOT, LAT, LON, CENTER, catalog, exposure, project

mpl.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titleweight':'bold',
    'axes.labelcolor':'#344451','font.size':9,'text.color':'#182b37','xtick.color':'#344451',
    'ytick.color':'#344451','axes.spines.top':False,'axes.spines.right':False,
    'axes.edgecolor':'#a8b1b7','axes.linewidth':.6,'svg.fonttype':'none','pdf.fonttype':42})
DARK='#182b37'
GREY='#4c616e'
ORANGE='#a74c14'
BLUE='#176779'
COLORS=[ORANGE,BLUE]
NAMES=['ComCat','Shelly relocated']
ORDER=['comcat','shelly']
OUT=Path(__file__).resolve().parent
DATA=json.loads((OUT/'results.json').read_text('utf-8'))
items=[DATA['catalogs'][key] for key in ORDER]

def header(fig,title,deck):
    fig.text(.078,.962,title,fontsize=19,fontweight='bold',va='top')
    fig.text(.078,.915,deck,fontsize=9.5,color=GREY,va='top')

def axis_title(ax,letter,title):
    ax.set_title(f'{letter}  {title}',loc='left',fontsize=10.5,pad=8)

def grid(ax):
    ax.set_axisbelow(True)
    ax.grid(axis='y',color='#dce3e5',linewidth=.6)

def save(fig,name,alias=False):
    for suffix in ['.pdf','.svg']:
        fig.savefig(OUT/(name+suffix),facecolor='white')
    if alias:
        fig.savefig(OUT/'primary-preview.png',dpi=240,facecolor='white')
        with Image.open(OUT/'primary-preview.png') as im:
            im.convert('RGB').save(OUT/'figure.webp',quality=96,method=6)
        (OUT/'figure.svg').write_bytes((OUT/(name+'.svg')).read_bytes())
    plt.close(fig)

def build_primary():
    fig=plt.figure(figsize=(9,7.3),facecolor='white')
    header(fig,'Two catalogs, two apparent decay rates',
           '2019 Ridgecrest sequence  |  Common spatial window and reported magnitude threshold')
    g=fig.add_gridspec(2,2,left=.095,right=.927,top=.85,bottom=.105,width_ratios=(1,1),
                      height_ratios=(1.05,1),wspace=.35,hspace=.53)
    map_group=g[0,:].subgridspec(1,3,wspace=.23,width_ratios=[1,1,.052])
    cmap=LinearSegmentedColormap.from_list('occupancy',['#e8eff0','#8eb5bb','#3f8895','#153b50'])
    norm=LogNorm(1,200,clip=True)
    for i,key in enumerate(ORDER):
        ax=fig.add_subplot(map_group[i])
        t,lat,lon,m=catalog(key)[0].T
        mask=(t>=1)&(t<72)&(m>=1.5)
        x,y=project(lat,lon)
        x_edges=np.arange(-48,42,2)
        y_edges=np.arange(-54,42,2)
        hist,_,_=np.histogram2d(x[mask],y[mask],bins=(x_edges,y_edges))
        assert hist.sum()==mask.sum()
        ax.set_facecolor('#f2f4f2')
        mesh=ax.pcolormesh(x_edges,y_edges,np.ma.masked_equal(hist.T,0),norm=norm,cmap=cmap,rasterized=False)
        phi=np.linspace(0,2*np.pi,300)
        ax.plot(30*np.cos(phi),30*np.sin(phi),linestyle=(0,(2,3)),color='#536871',linewidth=.65)
        ax.plot(0,0,marker='*',markersize=9,markerfacecolor='#eb9c50',markeredgecolor=DARK,markeredgewidth=.6,zorder=5)
        ax.plot([-42,-22],[-47,-47],color=DARK,lw=1.45,solid_capstyle='butt')
        ax.text(-32,-44,'20 km',ha='center',fontsize=7.5,color=DARK)
        ax.annotate('N',xy=(30,22),xytext=(30,13),ha='center',fontsize=8,
                    arrowprops={'width':.6,'headwidth':4,'headlength':4,'color':DARK})
        ax.set(aspect='equal',xlim=(-47,38),ylim=(-53,38),xticks=[-40,-20,0,20],yticks=[-40,-20,0,20],
               xlabel='East of mainshock (km)')
        if i==0:
            ax.set_ylabel('North of mainshock (km)')
        axis_title(ax,'AB'[i],NAMES[i])
        ax.text(.98,.965,f'{int(mask.sum()):,} events',transform=ax.transAxes,ha='right',va='top',
                bbox=dict(facecolor='white',edgecolor='none',alpha=.88,pad=2.3),fontsize=7.7)
    cax=fig.add_subplot(map_group[2])
    box=cax.get_position()
    cax.set_position([box.x0,box.y0+.073,box.width*.65,box.height*.58])
    cb=fig.colorbar(mesh,cax=cax,ticks=[1,5,20,100,200])
    cb.ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _:f'{x:g}' if x<200 else '≥200'))
    cb.ax.tick_params(labelsize=8,length=2)
    cb.ax.set_title('Events /\n2 km cell',fontsize=8,loc='left',y=1.02)
    ax=fig.add_subplot(g[1,0])
    edges=np.array(DATA['bins'])
    center=np.sqrt(edges[:-1]*edges[1:])
    ax.axvspan(72,216,color='#e9eff0',lw=0)
    ax.axvline(1,color='#94a0a7',ls=':',lw=1)
    ax.axvline(72,color='#94a0a7',ls=':',lw=1)
    for i,item in enumerate(items):
        fit=item['fits'][1][1]
        ax.plot(center,np.array(item['time_bins'])/np.diff(edges),mfc='white',color=COLORS[i],
                ms=3.8,marker='os'[i],linestyle='none',label=NAMES[i],zorder=3)
        x=np.geomspace(1,216,180)
        for k,dash in enumerate(['-','--']):
            keep=x<=72 if k==0 else x>72
            ax.plot(x[keep],fit['amplitude']/x[keep]**fit['p'],color=COLORS[i],lw=1.5,ls=dash)
    ax.set(xscale='log',yscale='log',xlim=(.25,216),ylim=(9,900),xlabel='Hours after Mw 7.1',ylabel='Events per hour')
    ax.set_xticks([.25,1,6,24,72,216],['¼','1','6','24','72','216'])
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_yticks([10,30,100,300],['10','30','100','300'])
    ax.text(124,425,'Held',color=GREY,fontsize=7.7,ha='center')
    ax.legend(loc='upper left',bbox_to_anchor=(-.032,1.008),ncols=2,frameon=False,fontsize=7.2,handletextpad=.25,columnspacing=.65)
    ax.set_title('C  Observed rate and fitted decay',loc='left',fontsize=10.5,pad=23)
    grid(ax)
    ax=fig.add_subplot(g[1,1])
    deltas=np.array([[items[1]['fits'][i][j]['p']-items[0]['fits'][i][j]['p']
                          for j in range(5)] for i in range(5)])
    gap=LinearSegmentedColormap.from_list('slope',['#1b566d','#7aabb0','#edf4f3'])
    ax.imshow(deltas,vmin=-.40,vmax=0,cmap=gap,aspect='auto')
    for i in range(5):
        for j in range(5):
            ax.text(j,i,f'{deltas[i,j]:.2f}'.replace('-','−'),ha='center',va='center',fontsize=8.5,
                    color='white' if deltas[i,j]<-.18 else DARK)
    ax.add_patch(plt.Rectangle((.52,.52),.96,.96,fill=False,lw=1.9,color='#63220e'))
    ax.set_xticks(range(5),['1.0','1.5','2.0','2.5','3.0'])
    ax.set_yticks(range(5),['¼','1','3','6','12'])
    ax.set(xlabel='Minimum reported magnitude',ylabel='First hour included')
    ax.set_xticks(np.arange(-.5,5,1),minor=True)
    ax.set_yticks(np.arange(-.5,5,1),minor=True)
    ax.tick_params(axis='both',which='both',length=0)
    ax.grid(which='minor',color='white',lw=1)
    axis_title(ax,'D','Shelly − ComCat decay exponent')
    fig.text(.095,.019,'MAPS & RATES   M ≥ 1.5     /     FITS   end at 72 h     /     OUTLINED CELL   primary comparison',
             fontsize=8.3,color=GREY)
    save(fig,'fig1_decay',True)

def build_diagnostics():
    fig=plt.figure(figsize=(9,4.8),facecolor='white')
    header(fig,'The catalog contrast changes through time',
           'Recorded proportions vary by elapsed time and reported magnitude')
    g=fig.add_gridspec(1,2,left=.10,right=.958,top=.80,bottom=.22,wspace=.35)
    a,b=map(fig.add_subplot,g)

    windows=['0–¼','¼–1','1–6','6–24','24–72','72–216']
    x=np.arange(6)
    cmap=LinearSegmentedColormap.from_list('frac',['#edf4f3','#b3ccd0','#498693','#1a5264'])
    fractions=np.array([i['counts'] for i in items])
    for idx,i in enumerate(items):
        early=np.array(i['early_subthreshold'])*100
        b.plot(x[1:],early,'o-' if idx==0 else 's-',
               color=COLORS[idx],mfc='white',lw=1.75,ms=5,label=NAMES[idx])
    ratio=fractions[1]/fractions[0]
    # Keep count ratios and rate denominators visible in the Results table.
    im=a.imshow(ratio.T,cmap=cmap,vmin=.35,vmax=1.85,aspect='auto')
    for i in range(6):
        for j in range(5):
            a.text(i,j,f'{ratio[i,j]:.2f}',fontsize=8,ha='center',va='center',
                   color='white' if ratio[i,j]>1.35 else DARK)
    a.set_xticks(x,windows,rotation=30,ha='right')
    a.set_yticks(range(5),['1.0','1.5','2.0','2.5','3.0'])
    a.set(ylabel='Minimum reported magnitude',xlabel='Elapsed-time window (h)')
    a.set_xticks(np.arange(-.5,6,1),minor=True)
    a.set_yticks(np.arange(-.5,5,1),minor=True)
    a.tick_params(axis='both',which='both',length=0)
    a.grid(which='minor',color='white',lw=1)
    b.set_xticks(x[1:],windows[1:],rotation=30,ha='right')
    b.set(ylim=(-3,88),ylabel='Share of all records (%)',xlabel='Elapsed-time window (h)')
    b.legend(frameon=False,fontsize=8,loc='upper left',labelspacing=.35)
    grid(b)
    axis_title(a,'A','Event count ratio, Shelly / ComCat')
    axis_title(b,'B','Records below magnitude 1.5')
    fig.text(.10,.042,'Ratios compare catalog totals within each window. Magnitudes retain the values published by each catalog.',
             fontsize=8.3,color=GREY)
    save(fig,'fig2_counts')

if __name__=='__main__':
    build_primary()
    build_diagnostics()

