# Catalog dependence of early aftershock decay in the 2019 Ridgecrest sequence

A descriptive one-sequence comparison of two public datasets. Browse the five-page paper in paper.pdf. The editable document is paper.tex, which uses the two vector figure PDFs. The editable SVG artwork accompanies them. The separate hero graphic summarizes the rate curves for public viewing.

## Reproduction

Use Python 3.12 or newer with NumPy, SciPy, Matplotlib and Pillow. Fetch the two files in sources.json into the directory with analyze.py, keeping the specified filenames. Verify their SHA-256 values before comparing your results to results.json. The Shelly data are archived. ComCat is a living service, so it may return a newer historical snapshot; changes in the query response are possible. The local research record preserves the original inputs.

```text
python -B analyze.py
python -B figures.py
python -B hero.py
xelatex -interaction=nonstopmode -halt-on-error paper.tex
xelatex -interaction=nonstopmode -halt-on-error paper.tex
```

The paper uses TeX Gyre Pagella and Heros. The figures use DejaVu Sans, which Matplotlib distributes. No site or installation assets are required to build the paper. The journal-style layout was selected for a research demonstration. No author, affiliation or target journal has been supplied.

## Scope

The catalogs share waveforms and records. The estimated decay exponent describes the reported events, conditional on the elapsed-time fit and reported magnitude cut. The count contrasts cannot partition routine detection, template coverage, reporting, relocation and preferred-magnitude effects. Held-time model checks use later observations in the same sequence. Data and figure provenance are in the paper and sources.json.

## PaperSpine editions

GPT-6.1 Sol performed the study once and followed the installed beta.2 instructions in three local workflows, sharing the same evidence. The Full Workflow Skill created the study and first compiled manuscript. The Skills Pack used the individual study, Followwriting, scientific figure, review and delivery instructions to revise the full draft against the evidence. The optional Windows workbench exercised live configuration, manuscript preview/download and browser feedback with a revised manuscript on the same task. See execution.json for workflow evidence. These are mode trials of one study.
