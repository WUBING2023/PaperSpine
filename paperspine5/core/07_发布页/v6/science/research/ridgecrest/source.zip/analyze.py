from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone
from hashlib import file_digest
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize_scalar

ROOT = Path(__file__).resolve().parent
T0 = datetime.fromisoformat('2019-07-06T03:19:53.040+00:00')
LAT, LON = (35.3, 36.1), (-118.1, -117.2)
CENTER = (35.7695, -117.5993333)
THRESHOLDS = [1., 1.5, 2., 2.5, 3.]
STARTS = [.25, 1., 3., 6., 12.]
EDGES = np.array([.25,.5,1,1.5,2.5,4,6,9,13,18,24,36,48,72,108,144,216])
EARTH_RADIUS = 6371.0088


def digest(path):
    with path.open('rb') as file:
        return file_digest(file, 'sha256').hexdigest()


def public_rows(name):
    origin_shift = lambda time: (time - T0).total_seconds() / 3600
    if name == 'comcat':
        with (ROOT/'comcat.csv').open(newline='', encoding='utf-8') as file:
            for row in csv.DictReader(file):
                if row['mag'] and row['type'] == 'earthquake' and row['id'] != 'ci38457511':
                    yield (origin_shift(datetime.fromisoformat(row['time'])), float(row['latitude']),
                           float(row['longitude']), float(row['mag']), row['id'], row['magType'])
    else:
        with (ROOT/'DataS1_noXYZ.txt').open(encoding='utf-8-sig') as file:
            for line in file:
                if line.startswith('#') or not line.strip():
                    continue
                y,mo,d,h,mi,s,lat,lon,depth,m,id_ = line.split()
                dt = datetime(*map(int, [y,mo,d,h,mi]),tzinfo=timezone.utc)+timedelta(seconds=float(s))
                yield (origin_shift(dt),float(lat),float(lon),float(m),id_,'native')


def catalog(name):
    rows = list(public_rows(name))
    assert len({row[4] for row in rows}) == len(rows), 'Duplicate event IDs'
    # Origin for a relocated version of the large mainshock can differ slightly.
    eligible = [row for row in rows if 0<row[0]<216 and LAT[0]<=row[1]<=LAT[1]
                and LON[0]<=row[2]<=LON[1] and not (row[0]<1/60 and row[3]>=6)]
    assert eligible
    return np.asarray([row[:4] for row in eligible]), rows


def project(lat, lon):
    lat, lon, lat0, lon0 = map(np.radians, (lat, lon, CENTER[0], CENTER[1]))
    delta = lon-lon0
    cos_c = np.clip(np.sin(lat0)*np.sin(lat)+np.cos(lat0)*np.cos(lat)*np.cos(delta), -1,1)
    arc = np.arccos(cos_c)
    scale = EARTH_RADIUS / np.sinc(arc/np.pi)
    return (scale*np.cos(lat)*np.sin(delta),
            scale*(np.cos(lat0)*np.sin(lat)-np.sin(lat0)*np.cos(lat)*np.cos(delta)))


def exposure(a,b,p,c):
    a, b = np.asarray(a)+c, np.asarray(b)+c
    if abs(1-p) < 1e-8:
        return np.log(b/a)
    return np.exp((1-p)*np.log(a))*np.expm1((1-p)*np.log(b/a))/(1-p)


def fit(t, a, c=0.):
    train=t[(t>=a)&(t<72)]
    held=t[(t>=72)&(t<216)]
    assert len(train)>2
    sum_logs=np.log(train+c).sum()
    def nll(p):
        return p*sum_logs+len(train)*np.log(exposure(a,72,p,c))
    solution=minimize_scalar(nll, bounds=(-1,3), method='bounded',
                             options={'xatol':1e-10})
    p=float(solution.x)
    assert solution.success and -.99 < p < 2.99
    k=float(len(train)/exposure(a,72,p,c))
    predicted=float(k*exposure(72,216,p,c))
    return dict(p=p, amplitude=k, train=len(train), held=len(held), predicted=predicted,
                held_to_predicted=len(held)/predicted, c=c)


def analyze():
    summary={}
    for name in ('comcat','shelly'):
        data, raw=catalog(name)
        t,lat,lon,m=data.T
        x,y=project(lat,lon)
        primary=t[m>=1.5]
        grid=[[fit(t[m>=cut], a) for cut in THRESHOLDS] for a in STARTS]
        counts=[]
        for a,b in [(0,.25),(.25,1),(1,6),(6,24),(24,72),(72,216)]:
            counts.append([int(np.count_nonzero((a<=t)&(t<b)&(m>=cut))) for cut in THRESHOLDS])
        summary[name]=dict(rows_loaded=len(raw),rows_selected=len(t),fits=grid,
           offset=fit(primary,1,1),central=fit(t[(m>=1.5)&(np.hypot(x,y)<=30)],1),
           counts=counts, time_bins=np.histogram(primary,bins=EDGES)[0].tolist(),
           early_subthreshold=[float((m[(t>=a)&(t<b)]<1.5).mean()) for a,b in [(.25,1),(1,6),(6,24),(24,72),(72,216)]],
           magnitude_types={kind:sum(row[5]==kind for row in raw) for kind in sorted(set(row[5] for row in raw))})
    assert exposure(1,72,1,0)==np.log(72)
    assert np.isclose(exposure(1,72,0,0),71)
    assert np.allclose(project(*CENTER),(0,0))
    result=dict(origin=T0.isoformat(),bounds={'latitude':LAT,'longitude':LON},
                thresholds=THRESHOLDS, starts=STARTS, bins=EDGES.tolist(), catalogs=summary,
                hashes={name:digest(ROOT/name) for name in ('comcat.csv','DataS1_noXYZ.txt')})
    (ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return result


if __name__=='__main__':
    result=analyze()
    for k, c in result['catalogs'].items():
        print(k,c['rows_loaded'],c['rows_selected'],c['fits'][1][1],c['offset'],c['central'])
        print(c['counts'])
        print(np.round([[fit['p'] for fit in row] for row in c['fits']],3))
