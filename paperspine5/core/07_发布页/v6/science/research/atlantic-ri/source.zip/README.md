# Atlantic cyclone intensification across comparable starting conditions

PaperSpine V6 public research demonstration. The paper compares 24-hour maximum wind gains in the NOAA National Hurricane Center's North Atlantic best track for 1982–2002 and 2003–2023. The comparison covers 6,017 windows across 37 shared starting contexts. At 30 knots, the later-minus-earlier difference was +0.81 percentage points (95% season-bootstrap interval −1.69 to +3.43). See the paper for selection, sensitivity to different thresholds, and interpretation.

## Reproduce the study

The source includes the editable LaTeX manuscript, the initial protocol, Python code, and the displayed figure exports and result table. Python 3.12 with NumPy 2.2.6, Shapely 2.1.2, Matplotlib 3.10.9, Pillow 12.2.0 and PyMuPDF 1.24.14 generated the results and plots. The original figure typography uses Arial. The manuscript was built with pdfLaTeX from TeX Live 2025 and the NewTX fonts.

Run these commands from the extracted directory.

~~~text
python -X utf8 fetch_data.py
python analyze.py
python figures.py
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=out paper.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=out paper.tex
~~~

The retrieval step checks both byte length and SHA-256 against `sources.json`. The 7.1 MB HURDAT2 archive and 1.6 MB land GeoJSON are available from their primary sources. If you already have those versions, place them in `inputs/` with the filenames recorded in the manifest. To rebuild the manuscript with the included figure PDFs, run only the two LaTeX commands.

- `analyze.py` writes the seven specifications, annual counts, and season exclusions to `out/results.json`. Its separate `out/windows.npz` feeds `figures.py`.
- `figures.py` renders the six-panel main figure and four-panel sensitivity figure as PDF, editable SVG and WebP. View or edit `out/figure.svg` and `out/checks.svg` in a vector editor that preserves text.
- `paper.tex` links the claim, reference, and figure placements. The compiled reading copy is available from the [research collection](https://wubing2023.github.io/PaperSpine/v6/#atlantic-ri).

Track data and geometry provenance are documented in [HURDAT2](https://www.nhc.noaa.gov/data/#hurdat) and the [Natural Earth vector release](https://github.com/nvkelso/natural-earth-vector/tree/v5.1.2).
