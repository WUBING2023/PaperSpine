"""Retrieve the two pinned public inputs and verify them before writing."""

from hashlib import sha256
import json
from pathlib import Path
from urllib.request import urlopen


def main():
    directory = Path(__file__).resolve().parent
    inputs = directory / "inputs"
    inputs.mkdir(exist_ok=True)
    sources = json.loads((directory / "sources.json").read_bytes())
    for name, source in sources.items():
        path = inputs / name
        if path.exists():
            payload = path.read_bytes()
        else:
            with urlopen(source["url"], timeout=60) as response:
                payload = response.read(source["bytes"] + 1)
        if len(payload) != source["bytes"] or sha256(payload).hexdigest() != source["sha256"]:
            raise ValueError(f"Input {name} does not match the study's pinned version")
        if not path.exists():
            path.write_bytes(payload)
        print(f"{name} verified ({len(payload):,} bytes)")


if __name__ == "__main__":
    main()
