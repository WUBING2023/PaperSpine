"""Export the recorded paths and result table used in the website explorer."""

from collections import defaultdict
from datetime import datetime, timedelta
import json
from pathlib import Path
import sys

import numpy as np
from shapely import make_valid
from shapely.geometry import box, shape

from analyze import records


ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "inputs/hurdat2.txt"
LOWEST_THRESHOLD = 15


def names_by_identifier():
    names = {}
    with ARCHIVE.open(encoding="ascii") as archive:
        for line in archive:
            if line.startswith("AL") and "," in line:
                identifier, name, *_ = line.split(",")
                names[identifier.strip()] = name.strip()
    return names


def track_windows(selected):
    names = names_by_identifier()
    by_storm = defaultdict(list)
    for row in selected[selected["gain"] >= LOWEST_THRESHOLD]:
        by_storm[row["storm"]].append(row)
    output = []
    for storm, fixes in records(ARCHIVE):
        for row in by_storm.get(storm, ()):
            start = datetime.fromisoformat(row["time"])
            path = [fixes[start + timedelta(hours=step)] for step in range(0, 25, 6)]
            track = [value for fix in path for value in (fix.lon, fix.lat)]
            output.append([
                storm, names[storm].title(), row["time"], int(row["gain"]), [fix.wind for fix in path], track,
            ])
    return output


def coast_polygons():
    extent = box(-143, -24, 25, 75)
    source = json.loads((ROOT / "inputs/ne_50m_land.geojson").read_bytes())
    items = []
    for feature in source["features"]:
        geometry = shape(feature["geometry"])
        if geometry.intersects(extent):
            visible = make_valid(geometry).intersection(extent).simplify(.075, preserve_topology=True)
            items.extend([visible] if visible.geom_type == "Polygon" else visible.geoms)
    return [
        [[round(position, 3) for xy in ring.coords for position in xy]
         for ring in (polygon.exterior, *polygon.interiors)]
        for polygon in items if polygon.geom_type == "Polygon"
    ]


def main(destination):
    stats = json.loads((ROOT / "out/results.json").read_bytes())
    with np.load(ROOT / "out/windows.npz") as data:
        tracks = track_windows(data["selected"])
    profile = stats["threshold_profile"]
    for point in profile:
        counts = [0, 0]
        for _, _, date, gain, _, _ in tracks:
            counts[int(date[:4] >= "2003")] += gain >= point["threshold"]
        if counts != point["events"]:
            raise ValueError(f"Explorer windows differ from the paper at {point['threshold']} kt")
    result = {
        "totals": stats["primary"]["windows"],
        "profile": profile,
        "tracks": tracks,
        "land": coast_polygons(),
    }
    destination.write_text(json.dumps(result, separators=(",", ":")) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "out/explorer.json")
