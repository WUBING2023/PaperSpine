"""Reproduce the observed Atlantic best-track rate comparison."""

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from hashlib import sha256
import json
from pathlib import Path
import re

import numpy as np
import shapely
from shapely.geometry import box, shape


HERE = Path(__file__).resolve().parent
YEARS = np.arange(1982, 2024)
EARLY_PERIOD = (1982, 2002)
LATE_PERIOD = (2003, 2023)
STRATA = 48
BOOT_DRAWS = 2400
SEED = 2812
SYNOPTIC = {"0000", "0600", "1200", "1800"}
DISPLAY_THRESHOLDS = (15, 20, 25, 30, 35, 40, 45, 50, 55)


@dataclass(frozen=True)
class Fix:
    timestamp: datetime
    wind: int
    status: str
    lon: float
    lat: float


def verify_inputs():
    ledger = json.loads((HERE / "sources.json").read_bytes())
    for name, item in ledger.items():
        payload = (HERE / "inputs" / name).read_bytes()
        if sha256(payload).hexdigest() != item["sha256"]:
            raise ValueError(f"Unexpected input checksum for {name}")


def coordinate(value):
    return float(value[:-1]) * (-1 if value[-1] in "WS" else 1)


def records(path):
    storm = None
    track = {}
    seen, expected = 0, 0
    with path.open(encoding="ascii") as stream:
        for line in stream:
            row = [entry.strip() for entry in line.split(",")]
            if re.fullmatch(r"AL\d{6}", row[0]):
                if storm is not None:
                    if seen != expected:
                        raise ValueError(f"Unexpected number of fixes in {storm}")
                    yield storm, track
                storm, track, seen, expected = row[0], {}, 0, int(row[2])
                continue
            if not row[0]:
                continue
            seen += 1
            if int(storm[-4:]) not in YEARS or row[1] not in SYNOPTIC:
                continue
            timestamp = datetime.strptime(row[0] + row[1], "%Y%m%d%H%M")
            if timestamp in track:
                raise ValueError(f"Duplicate synoptic fix: {storm}, {timestamp}")
            track[timestamp] = Fix(timestamp, int(row[6]), row[3], coordinate(row[5]), coordinate(row[4]))
    if seen != expected:
        raise ValueError(f"Unexpected number of fixes in {storm}")
    yield storm, track


def load_land(path):
    region = box(-105, -5, -8, 55)
    polygons = []
    for feature in json.loads(path.read_bytes())["features"]:
        polygon = shape(feature["geometry"])
        if polygon.intersects(region):
            polygons.append(shapely.make_valid(polygon).intersection(region))
    return shapely.union_all(polygons)


def extract_rows(path, land):
    rows = []
    for storm, track in records(path):
        season = int(storm[-4:])
        for timestamp, start in track.items():
            if start.status not in {"TS", "HU"} or not 35 <= start.wind <= 95:
                continue
            if not (6 <= timestamp.month <= 11 and 5 <= start.lat < 40 and -100 <= start.lon < -15):
                continue
            window = [track.get(timestamp + timedelta(hours=6 * step)) for step in range(5)]
            if any(fix is None or fix.wind < 0 or fix.status not in {"TS", "HU", "TD"} for fix in window):
                continue
            area = int(start.lon >= -75) + int(start.lon >= -50)
            lat = int(start.lat >= 25)
            late_month = int(start.timestamp.month >= 9)
            wind = int(start.wind >= 50) + int(start.wind >= 65) + int(start.wind >= 80)
            context = (((area * 2) + lat) * 2 + late_month) * 4 + wind
            rows.append((
                storm, season, timestamp.isoformat(), start.wind, start.lon, start.lat, context,
                window[-1].wind - start.wind, timestamp.hour, all(fix.status != "TD" for fix in window),
                [fix.lon for fix in window], [fix.lat for fix in window],
            ))
    longitude = np.array([r[-2] for r in rows])
    latitude = np.array([r[-1] for r in rows])
    over_water = ~shapely.intersects_xy(land, longitude, latitude).any(axis=1)
    dtype = [
        ("storm", "U8"), ("year", "i2"), ("time", "U19"), ("wind", "i2"), ("lon", "f8"),
        ("lat", "f8"), ("context", "i2"), ("gain", "i2"), ("hour", "i2"), ("persistent", "?"), ("water", "?"),
    ]
    return np.array([(*row[:-2], water) for row, water in zip(rows, over_water, strict=True)], dtype=dtype)


def by_season(rows, threshold):
    indices = (rows["year"] - YEARS[0]) * STRATA + rows["context"]
    total = np.bincount(indices, minlength=len(YEARS) * STRATA).reshape(len(YEARS), STRATA)
    events = np.bincount(indices, weights=(rows["gain"] >= threshold),
                         minlength=len(YEARS) * STRATA).reshape(len(YEARS), STRATA)
    return total, events


def components(total, events):
    shares = total / total.sum(axis=-1, keepdims=True)
    rates = events / total
    rate = (shares * rates).sum(axis=-1)
    within = (shares.mean(axis=-2) * (rates[..., 1, :] - rates[..., 0, :])).sum(axis=-1)
    mix = (rates.mean(axis=-2) * (shares[..., 1, :] - shares[..., 0, :])).sum(axis=-1)
    raw = rate[..., 1] - rate[..., 0]
    np.testing.assert_allclose(raw, within + mix, rtol=0, atol=2e-14)
    return np.stack((raw, within, mix), axis=-1) * 100, rate * 100


def estimate(eligible, threshold, draws):
    total, events = by_season(eligible, threshold)
    total_eras = total.reshape(2, 21, STRATA)
    event_eras = events.reshape(2, 21, STRATA)
    support = (total_eras.sum(axis=1).min(axis=0) >= 20) & ((total_eras > 0).sum(axis=1).min(axis=0) >= 5)
    if not support.any():
        raise ValueError("No comparable starting contexts")
    n, e = total_eras[:, :, support], event_eras[:, :, support]
    totals, counts = n.sum(axis=1), e.sum(axis=1)
    effects, rates = components(totals, counts)
    boot_n = np.stack([draws[era] @ n[era] for era in range(2)], axis=1)
    boot_e = np.stack([draws[era] @ e[era] for era in range(2)], axis=1)
    retained = (boot_n > 0).all(axis=(1, 2))
    boot_effects, _ = components(boot_n[retained], boot_e[retained])
    return {
        "threshold": threshold,
        "eligible": total_eras.sum(axis=(1, 2)).tolist(),
        "windows": totals.sum(axis=1).tolist(),
        "events": counts.sum(axis=1).astype(int).tolist(),
        "rates_pct": rates.tolist(),
        "effects_pp": effects.tolist(),
        "intervals_pp": np.percentile(boot_effects, [2.5, 97.5], axis=0).T.tolist(),
        "bootstrap_valid": int(retained.sum()),
        "support": np.flatnonzero(support).tolist(),
        "context_n": totals.tolist(),
        "context_k": counts.astype(int).tolist(),
    }


def yearly(rows, threshold):
    output = []
    for year in YEARS:
        block = rows[rows["year"] == year]
        output.append({"year": int(year), "n": len(block), "k": int(np.count_nonzero(block["gain"] >= threshold))})
    return output


def omit_seasons(rows, support):
    total, events = by_season(rows, 30)
    n = total[:, support].reshape(2, 21, -1)
    e = events[:, support].reshape(2, 21, -1)
    result = []
    for index, year in enumerate(YEARS):
        era, position = divmod(index, 21)
        sum_n, sum_e = n.sum(axis=1), e.sum(axis=1)
        sum_n[era] -= n[era, position]
        sum_e[era] -= e[era, position]
        effect, _ = components(sum_n, sum_e)
        result.append({"year": int(year), "effects_pp": effect.tolist()})
    return result


def main():
    verify_inputs()
    land = load_land(HERE / "inputs/ne_50m_land.geojson")
    rows = extract_rows(HERE / "inputs/hurdat2.txt", land)
    primary = rows[(rows["wind"] <= 85) & rows["persistent"]]
    draws = np.random.default_rng(SEED).multinomial(21, np.full(21, 1 / 21), size=(2, BOOT_DRAWS))
    scenarios = {
        "primary": (primary, 30),
        "threshold25": (primary, 25),
        "threshold35": (primary, 35),
        "utc00": (primary[primary["hour"] == 0], 30),
        "water": (primary[primary["water"]], 30),
        "allow_td": (rows[rows["wind"] <= 85], 30),
        "wind95": (rows[rows["persistent"]], 30),
    }
    results = {key: estimate(sample, cutoff, draws) for key, (sample, cutoff) in scenarios.items()}
    support = results["primary"]["support"]
    central = {results[key]["threshold"]: results[key] for key in ("threshold25", "primary", "threshold35")}
    profile = [
        central[cutoff] if cutoff in central else estimate(primary, cutoff, draws)
        for cutoff in DISPLAY_THRESHOLDS
    ]
    for point in profile:
        if point["support"] != support:
            raise ValueError("Threshold curve must use the primary support")
    results["threshold_profile"] = [
        {key: item[key] for key in ("threshold", "events", "rates_pct", "effects_pp", "intervals_pp")}
        for item in profile
    ]
    selected = primary[np.isin(primary["context"], support)]
    results["annual"] = yearly(selected, 30)
    results["omit_season"] = omit_seasons(selected, support)
    results["storms"] = [len(set(selected["storm"][selected["year"] <= 2002])),
                          len(set(selected["storm"][selected["year"] >= 2003]))]
    results["bootstrap_draws"] = BOOT_DRAWS
    results["bootstrap_seed"] = SEED
    output = HERE / "out"
    output.mkdir(exist_ok=True)
    np.savez_compressed(output / "windows.npz", eligible=primary, selected=selected)
    (output / "results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8", newline="\n")
    for name in scenarios:
        summary = results[name]
        print(name, summary["eligible"], summary["windows"], summary["events"], summary["rates_pct"],
              summary["effects_pp"], summary["intervals_pp"], summary["bootstrap_valid"])


if __name__ == "__main__":
    main()
