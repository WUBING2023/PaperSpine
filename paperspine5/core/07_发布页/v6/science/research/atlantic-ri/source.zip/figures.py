"""Render the main comparison and robustness plates from the saved analysis."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.ticker import MaxNLocator
import numpy as np
from PIL import Image
import pymupdf

from analyze import load_land


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"
EARLY = "#1b6485"
LATE = "#b04426"
INK = "#192629"
MUTED = "#526269"
RULE = "#d5e0e0"
WITHIN = "#205a4d"
MIX = "#837021"
ERAS = (EARLY, LATE)
LABELS = {
    "primary": "Primary",
    "utc00": "00 UTC only",
    "water": "Water fixes",
    "allow_td": "Allow TD",
    "wind95": "Up to 95 kt",
    "threshold25": "25 kt",
    "threshold35": "35 kt",
}
matplotlib.rcParams.update({
    "font.family": ["Arial", "DejaVu Sans"], "font.size": 6.5, "axes.labelsize": 6.5,
    "axes.titlesize": 7, "axes.linewidth": .5, "xtick.labelsize": 6,
    "ytick.labelsize": 6, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "xtick.major.width": .45, "ytick.major.width": .45, "text.color": INK,
    "axes.labelcolor": INK, "axes.edgecolor": "#9caead", "xtick.color": MUTED,
    "ytick.color": MUTED, "legend.fontsize": 6.1, "pdf.fonttype": 42,
    "svg.fonttype": "none", "svg.hashsalt": "paperspine-atlantic-ri",
})


def panel(ax, letter, title):
    ax.set_title(f"{letter}   {title}", loc="left", pad=6, fontweight="bold")


def axes_style(ax, direction="y"):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis=direction, linewidth=.45, color=RULE, zorder=0)
    ax.set_axisbelow(True)


def polygons(geometry):
    if geometry.geom_type == "Polygon":
        yield geometry
    elif hasattr(geometry, "geoms"):
        for item in geometry.geoms:
            yield from polygons(item)


def era_map(ax, land, data, color, letter, label):
    ax.set_facecolor("#f5f9f9")
    for island in polygons(land):
        x, y = island.exterior.xy
        ax.fill(x, y, color="#e8e6dd", ec="#b2bdb7", lw=.28, zorder=1)
    rapid = data[data["gain"] >= 30]
    ax.scatter(data["lon"], data["lat"], s=1.4, c="#a3b7bd", alpha=.48, linewidth=0, zorder=2)
    ax.scatter(rapid["lon"], rapid["lat"], s=4.8, c=color, alpha=.82, linewidth=0, zorder=3)
    ax.set(xlim=(-100, -15), ylim=(5, 40), xticks=(-100, -75, -50, -25), yticks=(10, 20, 30, 40))
    ax.set_xticklabels(["100°W", "75°W", "50°W", "25°W"])
    ax.set_yticklabels(["10°N", "20°N", "30°N", "40°N"])
    ax.tick_params(pad=2)
    ax.grid(color="white", lw=.55, zorder=0)
    panel(ax, letter, f"{label}  |  {len(rapid):,}/{len(data):,} RI")


def tail(ax, windows):
    thresholds = np.arange(0, 66, 5)
    for era, color in enumerate(ERAS):
        subset = windows[(windows["year"] >= 2003) == bool(era)]["gain"]
        survival = 100 * (subset[:, None] >= thresholds).mean(axis=0)
        keep = survival > 0
        ax.plot(thresholds[keep], survival[keep], color=color, lw=1.03, ls="--" if era == 0 else "-",
                marker="o" if era == 0 else "s", ms=2.1, label=("1982–2002", "2003–2023")[era])
    ax.axvline(30, color="#647171", lw=.75, ls=":")
    ax.text(31.5, 24, "30 kt", fontsize=6, va="center")
    ax.set(xlim=(-1, 66), yscale="log", ylim=(.1, 100), xticks=(0, 15, 30, 45, 60),
           xlabel="24-h wind gain threshold (kt)", ylabel="Windows at or above (%)")
    ax.set_yticks([.1, 1, 10, 100], ["0.1", "1", "10", "100"])
    ax.tick_params(axis="y", which="minor", length=0)
    axes_style(ax)
    ax.legend(frameon=False, loc="lower left", handlelength=1.7, borderpad=.25)
    panel(ax, "c", "Upper tail of 24-h wind gains")


def seasons(ax, results):
    values = results["annual"]
    for era, color in enumerate(ERAS):
        block = values[era * 21:(era + 1) * 21]
        years = [item["year"] for item in block]
        rates = [100 * item["k"] / item["n"] for item in block]
        ax.plot(years, rates, color=color, lw=.8, marker="o", ms=2.2)
        ax.hlines(results["primary"]["rates_pct"][era], years[0], years[-1], colors=color,
                  linestyles="--", linewidth=.8)
    ax.axvline(2002.5, color="#a5b2ae", lw=.65)
    ax.set(xlim=(1981, 2024), ylim=(0, None), xticks=(1982, 1992, 2002, 2012, 2023),
           xlabel="Season", ylabel="RI windows (%)")
    ax.yaxis.set_major_locator(MaxNLocator(4))
    axes_style(ax)
    panel(ax, "d", "Season-to-season variation")


def changes(ax, result, figure):
    support = np.array(result["support"])
    n = np.asarray(result["context_n"])
    k = np.asarray(result["context_k"])
    pool = (n / n.sum(axis=1, keepdims=True)).mean(axis=0)
    differences = 100 * (k[1] / n[1] - k[0] / n[0])
    grid = np.full((6, 4), np.nan)
    for band in range(6):
        for v in range(4):
            group = ((support // 8) == band) & ((support % 4) == v)
            if group.any():
                grid[band, v] = np.average(differences[group], weights=pool[group])
    limit = max(2, int(np.ceil(np.nanmax(np.abs(grid)))))
    palette = LinearSegmentedColormap.from_list("changes", ("#1a6787", "#f5f5ed", "#ac451d"))
    palette.set_bad("#e9edeb")
    heat = ax.imshow(grid, aspect="auto", cmap=palette, norm=TwoSlopeNorm(0, -limit, limit))
    for i, row in enumerate(grid):
        for j, value in enumerate(row):
            ax.text(j, i, f"{value:+.1f}" if np.isfinite(value) else "–", fontsize=6,
                    color="white" if abs(value) > .68 * limit else INK, ha="center", va="center")
    ax.set_xticks(range(4), ["35–49", "50–64", "65–79", "80–85"])
    ax.set_yticks(range(6), ["W <25°N", "W ≥25°N", "C <25°N", "C ≥25°N", "E <25°N", "E ≥25°N"])
    ax.tick_params(length=0, pad=2, labelsize=6)
    ax.set_xlabel("Starting wind (kt)", labelpad=3)
    ax.spines[:].set_visible(False)
    bar = figure.colorbar(heat, ax=ax, location="bottom", fraction=.08, pad=.31, aspect=22,
                          ticks=(-limit, 0, limit))
    bar.ax.tick_params(labelsize=5.4, pad=2, length=2)
    bar.set_label("Late minus early (pp)", fontsize=5.5, labelpad=1)
    panel(ax, "e", "Change by starting context")


def draw_interval(ax, value, interval, y, color, marker):
    ax.hlines(y, *interval, color=color, lw=.95)
    ax.plot([value], [y], marker=marker, color=color, ms=3.7, ls="none", zorder=3)


def decomposition(ax, result):
    values, intervals = result["effects_pp"], result["intervals_pp"]
    for row, (value, interval, color) in enumerate(zip(values, intervals, (INK, WITHIN, MIX), strict=True)):
        draw_interval(ax, value, interval, row, color, ("o", "s", "D")[row])
        ax.annotate(f"{value:+.2f}", (value, row), xytext=(0, 7), textcoords="offset points",
                    fontsize=6.0, ha="center", color=INK)
    ax.axvline(0, color="#516965", lw=.65, ls="--")
    ax.set(yticks=(0, 1, 2), yticklabels=("Total", "Within", "Mix"), ylim=(2.55, -.60),
           xlim=(-3.6, 4.0), xticks=(-3, -2, -1, 0, 1, 2, 3, 4), xlabel="Late minus early (pp)")
    ax.tick_params(axis="y", length=0)
    axes_style(ax, "x")
    panel(ax, "f", "Difference and its components")


def save_fig(figure, file, title):
    figure.savefig(OUT / f"{file}.pdf", metadata={"Title": title, "CreationDate": None, "ModDate": None})
    figure.savefig(OUT / f"{file}.svg", metadata={"Title": title, "Date": None})
    plt.close(figure)
    with pymupdf.open(OUT / f"{file}.pdf") as source:
        page = source[0]
        pix = page.get_pixmap(matrix=pymupdf.Matrix(2400 / page.rect.width, 2400 / page.rect.width), alpha=False)
        Image.frombytes("RGB", (pix.width, pix.height), pix.samples).save(
            OUT / f"{file}.webp", "WEBP", quality=91, method=6
        )


def main_plate(results, data, land):
    fig, ax = plt.subplots(2, 3, figsize=(183 / 25.4, 135 / 25.4))
    fig.subplots_adjust(left=.077, right=.987, bottom=.15, top=.89, wspace=.48, hspace=.58)
    era_map(ax[0, 0], land, data[data["year"] <= 2002], EARLY, "a", "1982–2002")
    era_map(ax[0, 1], land, data[data["year"] >= 2003], LATE, "b", "2003–2023")
    tail(ax[0, 2], data)
    seasons(ax[1, 0], results)
    changes(ax[1, 1], results["primary"], fig)
    decomposition(ax[1, 2], results["primary"])
    markers = [
        plt.Line2D([], [], marker="o", ls="", ms=3, color="#a3b7bd", label="Shared-context start"),
        plt.Line2D([], [], marker="o", ls="", ms=3.8, color=EARLY, label="RI, 1982–2002"),
        plt.Line2D([], [], marker="o", ls="", ms=3.8, color=LATE, label="RI, 2003–2023"),
    ]
    fig.legend(handles=markers, loc="center left", bbox_to_anchor=(.068, .551), ncols=3, frameon=False,
               handletextpad=.25, columnspacing=1.35, fontsize=6, markerscale=.95)
    fig.text(.077, .978, "Rapid intensification in the Atlantic best track", fontsize=7,
             ha="left", va="top", weight="bold")
    fig.text(.077, .944, "Shared contexts · 24-hour tropical-storm and hurricane windows · 42 seasons",
             color=MUTED, fontsize=6.2, va="top")
    fig.text(.077, .023, "NOAA NHC HURDAT2 · Land polygons from Natural Earth · RI = wind gain of at least 30 kt",
             fontsize=5.8, color=MUTED)
    save_fig(fig, "figure", "Rapid intensification in the Atlantic best track")


def spec_forest(ax, results, keys):
    for row, key in enumerate(keys):
        result = results[key]
        for index, color, mark, shift in ((0, INK, "o", -.115), (1, WITHIN, "s", .115)):
            draw_interval(ax, result["effects_pp"][index], result["intervals_pp"][index], row + shift, color, mark)
    ax.axvline(0, color="#6d7c77", lw=.7, ls=":")
    ax.set_yticks(range(len(keys)), [LABELS[key] for key in keys])
    ax.set(ylim=(len(keys) - .46, -.54), xlim=(-5.4, 7.1), xticks=(-4, -2, 0, 2, 4, 6),
           xlabel="Late minus early (pp)")
    ax.tick_params(axis="y", length=0)
    axes_style(ax, "x")


def robustness_plate(results):
    fig, ax = plt.subplots(2, 2, figsize=(183 / 25.4, 126 / 25.4))
    fig.subplots_adjust(left=.126, right=.98, bottom=.105, top=.889, wspace=.39, hspace=.55)
    variants = ["primary", "utc00", "water", "allow_td", "wind95"]
    spec_forest(ax[0, 0], results, variants)
    panel(ax[0, 0], "a", "Changes to cohort eligibility")
    spec_forest(ax[0, 1], results, ["threshold25", "primary", "threshold35"])
    ax[0, 1].set_yticklabels(["25 kt", "30 kt", "35 kt"])
    handles = [plt.Line2D([0], [0], marker=mark, color=color, ls="", ms=3.5, label=label)
               for color, mark, label in ((INK, "o", "Total"), (WITHIN, "s", "Within context"))]
    ax[0, 1].legend(handles=handles, loc="upper right", frameon=False, handletextpad=.18)
    panel(ax[0, 1], "b", "Outcome definition")

    coverage = ax[1, 0]
    tick = np.arange(len(variants))
    for era, color in enumerate(ERAS):
        fractions = [100 * results[key]["windows"][era] / results[key]["eligible"][era] for key in variants]
        coverage.barh(tick + (era - .5) * .28, fractions, height=.24, color=color, alpha=.88,
                      label=("1982–2002", "2003–2023")[era])
    coverage.set_yticks(tick, [LABELS[key] for key in variants])
    coverage.set(xlim=(0, 104), ylim=(len(variants) - .48, -.53), xticks=(0, 25, 50, 75, 100),
                 xlabel="Eligible windows retained (%)")
    coverage.tick_params(axis="y", length=0)
    axes_style(coverage, "x")
    coverage.legend(loc="center right", bbox_to_anchor=(.985, .689), frameon=False, handlelength=.95,
                    handletextpad=.45, borderpad=.25, labelspacing=.5)
    panel(coverage, "c", "Coverage of shared contexts")

    omit = ax[1, 1]
    for index, color, mark in ((0, INK, "o"), (1, WITHIN, "s")):
        effect = results["primary"]["effects_pp"][index]
        omit.axhline(effect, color=color, lw=.7, ls="--")
        leave_out = results["omit_season"]
        omit.scatter([item["year"] for item in leave_out], [item["effects_pp"][index] for item in leave_out],
                     color=color, marker=mark, s=6, linewidths=0)
    omit.axhline(0, lw=.65, color="#a4b2ae")
    omit.set(xlim=(1981, 2024), xticks=(1982, 1992, 2002, 2012, 2023),
             xlabel="Season omitted", ylabel="Difference (pp)")
    omit.yaxis.set_major_locator(MaxNLocator(4))
    axes_style(omit)
    panel(omit, "d", "Influence of individual seasons")
    fig.text(.126, .979, "Sensitivity to eligibility, threshold and season", fontsize=7,
             weight="bold", va="top")
    fig.text(.126, .942, "Whole-season bootstrap intervals in a–b; fixed-support exclusions in d",
             fontsize=6.2, color=MUTED, va="top")
    save_fig(fig, "checks", "Sensitivity to eligibility, threshold and season")


def main():
    stats = json.loads((OUT / "results.json").read_bytes())
    data = np.load(OUT / "windows.npz")["selected"]
    land = load_land(ROOT / "inputs/ne_50m_land.geojson")
    main_plate(stats, data, land)
    robustness_plate(stats)


if __name__ == "__main__":
    main()
