"""Render the main comparison and robustness plates from the saved analysis."""

from datetime import datetime, timedelta
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import PathPatch
from matplotlib.path import Path as DrawingPath
from matplotlib.ticker import MaxNLocator
import numpy as np
from PIL import Image
import pymupdf

from analyze import records
from export_explorer import coast_polygons


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"
EARLY = "#1b6485"
LATE = "#b04426"
INK = "#192629"
MUTED = "#526269"
RULE = "#d5e0e0"
WITHIN = "#205a4d"
MIX = "#837021"
ERAS = (EARLY, LATE)
LABELS = {
    "primary": "Primary",
    "utc00": "00 UTC only",
    "water": "Water fixes",
    "allow_td": "Allow TD",
    "wind95": "Up to 95 kt",
    "threshold25": "25 kt",
    "threshold35": "35 kt",
}
matplotlib.rcParams.update({
    "font.family": ["Arial", "DejaVu Sans"], "font.size": 6.5, "axes.labelsize": 6.5,
    "axes.titlesize": 7, "axes.linewidth": .5, "xtick.labelsize": 6,
    "ytick.labelsize": 6, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "xtick.major.width": .45, "ytick.major.width": .45, "text.color": INK,
    "axes.labelcolor": INK, "axes.edgecolor": "#9caead", "xtick.color": MUTED,
    "ytick.color": MUTED, "legend.fontsize": 6.1, "pdf.fonttype": 42,
    "svg.fonttype": "none", "svg.hashsalt": "paperspine-atlantic-ri",
})


def panel(ax, letter, title):
    ax.set_title(f"{letter}   {title}", loc="left", pad=6, fontweight="bold")


def axes_style(ax, direction="y"):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis=direction, linewidth=.45, color=RULE, zorder=0)
    ax.set_axisbelow(True)


def project(points):
    """Lambert conformal conic with standard parallels at 15 and 35°N."""
    lon, lat = np.asarray(points, dtype=float).T
    phi1, phi2 = np.deg2rad([15, 35])
    t1, t2 = np.tan(np.pi / 4 + np.array([phi1, phi2]) / 2)
    n = np.log(np.cos(phi1) / np.cos(phi2)) / np.log(t2 / t1)
    rho = np.cos(phi1) * t1 ** n / (n * np.tan(np.pi / 4 + np.deg2rad(lat) / 2) ** n)
    theta = n * np.deg2rad(lon + 59)
    return np.column_stack((rho * np.sin(theta), -rho * np.cos(theta)))


def track_segments(data):
    rapid = data[data["gain"] >= 30]
    by_storm = {storm: [] for storm in np.unique(rapid["storm"])}
    for window in rapid:
        by_storm[window["storm"]].append(window)
    segments = ([], [])
    for storm, fixes in records(ROOT / "inputs/hurdat2.txt"):
        for window in by_storm.get(storm, ()):
            start = datetime.fromisoformat(window["time"])
            path = [fixes[start + timedelta(hours=6 * step)] for step in range(5)]
            segments[int(window["year"] >= 2003)].append([(fix.lon, fix.lat) for fix in path])
    assert sum(map(len, segments)) == len(rapid)
    return tuple(np.asarray(era) for era in segments)


def trajectory_map(ax, land, data, result):
    water = "#edf4f5"
    ax.set_facecolor(water)
    for island in land:
        rings = [DrawingPath(project(np.reshape(ring, (-1, 2))), closed=True) for ring in island]
        ax.add_patch(PathPatch(DrawingPath.make_compound_path(*rings), facecolor="#e1e6db",
                               edgecolor="#8d9d91", lw=.32, zorder=1))
    for latitude in range(10, 51, 10):
        line = project([(lon, latitude) for lon in np.linspace(-130, 5, 105)])
        ax.plot(*line.T, color="#d1dfdf", lw=.45, zorder=2)
    for longitude in range(-120, 1, 20):
        line = project([(longitude, lat) for lat in np.linspace(-12, 64, 90)])
        ax.plot(*line.T, color="#d1dfdf", lw=.45, zorder=2)
    partitions = [
        [(lon, lat) for lat in np.linspace(-12, 64, 65)] for lon in (-75, -50)
    ] + [[(lon, 25) for lon in np.linspace(-130, 5, 120)]]
    for line in partitions:
        ax.plot(*project(line).T, color="#7d9698", lw=.56, ls=(0, (3, 3)), zorder=2)
    handles = []
    projected = []
    for era, (paths, color, years) in enumerate(zip(track_segments(data), ERAS, ("1982–2002", "2003–2023"), strict=True)):
        coords = project(paths.reshape(-1, 2)).reshape(paths.shape)
        projected.append(coords.reshape(-1, 2))
        ax.add_collection(LineCollection(coords, colors=color, lw=.63, alpha=.39, zorder=3))
        ax.scatter(coords[:, 0, 0], coords[:, 0, 1], s=5.3, facecolor=color, edgecolor="white",
                   linewidth=.23, alpha=.81, zorder=4)
        n, k = result["windows"][era], result["events"][era]
        assert len(coords) == k
        handles.append(plt.Line2D([], [], ls="-", marker="o", lw=.8, ms=3.3, color=color,
                                  label=f"{years}   {k:,}/{n:,}"))
    labels = [
        ((-100, 3.5), "100°W"), ((-80, 3.5), "80°W"), ((-60, 3.5), "60°W"),
        ((-40, 3.5), "40°W"), ((-20, 3.5), "20°W"),
        ((-104, 10), "10°N"), ((-104, 25), "25°N"), ((-104, 40), "40°N"),
    ]
    for location, label in labels:
        x, y = project([location])[0]
        ax.text(x, y, label, ha="center", va="center", color=MUTED, fontsize=5.1, zorder=5)
    for lon, label in ((-87, "WEST"), (-63, "CENTRAL"), (-34, "EAST")):
        x, y = project([(lon, 7)])[0]
        ax.text(x, y, label, ha="center", va="center", color=MUTED, fontsize=5.1,
                bbox={"fc": water, "ec": "none", "pad": 1}, zorder=5)
    x, y = project([(-45, 34)])[0]
    ax.text(x, y, "NORTH ATLANTIC", ha="center", va="center", color="#698688", fontsize=5.1, zorder=5)
    bounds = np.vstack([*projected, project([location for location, _ in labels]), project([(-66, 45)])])
    width, height = np.ptp(bounds, axis=0) + [.12, .09]
    center = (bounds.min(axis=0) + bounds.max(axis=0)) / 2
    rect = ax.get_position()
    fig = ax.figure
    ratio = rect.width * fig.get_figwidth() / (rect.height * fig.get_figheight())
    width = max(width, height * ratio)
    height = width / ratio
    ax.set(xlim=(center[0] - width/2, center[0] + width/2), ylim=(center[1] - height/2, center[1] + height/2),
           xticks=(), yticks=(), aspect="equal")
    ax.legend(handles=handles, ncols=2, loc="upper left", bbox_to_anchor=(-.013, -.035), frameon=False,
              handlelength=1.45, handletextpad=.58, borderaxespad=.35, columnspacing=1.9)
    panel(ax, "a", "24-h tracks gaining ≥30 kt")


def signed(value):
    return f"{value:+.2f}".replace("-", "−")


def gain_bands(ax, results):
    primary = results["primary"]
    exceedance = np.array([results[key]["events"] for key in ("threshold25", "primary", "threshold35")])
    brackets = exceedance - np.vstack([exceedance[1:], [0, 0]])
    rates = 100 * brackets / primary["windows"]
    for row, (early, late) in enumerate(rates):
        ax.plot([early, late], [row, row], color="#819191", lw=1.2, zorder=2)
        ax.scatter([early, late], [row, row], color=ERAS, s=17, lw=.45, edgecolor="white", zorder=3)
        ax.text(7.27, row, signed(late - early), ha="right", va="center",
                fontsize=6.5, color=LATE if late > early else EARLY, weight="bold")
    ax.text(7.27, -.57, "Δ pp", ha="right", va="center", color=MUTED, fontsize=5.8)
    ax.set(xlim=(0, 7.45), ylim=(2.66, -.66), xticks=(0, 2, 4, 6),
           yticks=(0, 1, 2), yticklabels=("25–<30", "30–<35", "≥35"),
           xlabel="Share of windows (%)")
    ax.set_ylabel("24-h gain (kt)", labelpad=4)
    ax.tick_params(axis="y", length=0)
    axes_style(ax, "x")
    ax.spines["left"].set_visible(False)
    panel(ax, "b", "Shares by wind-gain band")


def threshold_profile(ax, results):
    profile = results["threshold_profile"]
    cutoffs = np.array([point["threshold"] for point in profile])
    point = np.array([point["effects_pp"] for point in profile])
    interval = np.array([point["intervals_pp"][0] for point in profile])
    ax.fill_between(cutoffs, interval[:, 0], interval[:, 1], color="#c2dbe2", lw=0, alpha=.68, zorder=1)
    ax.axhline(0, lw=.6, color="#526a6a", zorder=2)
    ax.axvline(30, lw=.54, color="#7b8584", ls=(0, (2, 3)), zorder=2)
    ax.plot(cutoffs, point[:, 1], color=WITHIN, lw=.85, ls=(0, (2, 2)), zorder=3)
    ax.plot(cutoffs, point[:, 0], color="#1c4555", lw=1.05, marker="o", ms=2.6, zorder=4)
    for cutoff, delta, alignment in ((25, -.95, "top"), (30, .61, "bottom"), (35, .77, "bottom")):
        index = np.flatnonzero(cutoffs == cutoff)[0]
        value = point[index, 0]
        ax.scatter([cutoff], [value], s=18, c=[EARLY if value < 0 else LATE], lw=.5, edgecolor="white", zorder=5)
        ax.text(cutoff, value + delta, signed(value), ha="center", va=alignment, fontsize=6.3, color=INK)
    ax.set(xlim=(14, 56), ylim=(min(-5.5, interval.min() - .15), max(4.7, interval.max() + .15)),
           xticks=(15, 25, 30, 35, 45, 55), ylabel="Late minus early (pp)", xlabel="Wind-gain threshold (kt)")
    ax.yaxis.set_major_locator(MaxNLocator(4))
    axes_style(ax)
    handles = [
        plt.Line2D([], [], color="#1c4555", lw=1.05, marker="o", ms=2.5, label="Total, pointwise 95% interval"),
        plt.Line2D([], [], color=WITHIN, lw=.9, ls=(0, (2, 2)), label="Within contexts"),
    ]
    ax.legend(handles=handles, loc="lower right", ncols=2, frameon=False, handlelength=1.3,
              handletextpad=.5, borderpad=.35, columnspacing=.95)
    panel(ax, "c", "Exploratory contrast across thresholds")


def seasons(ax, results):
    values = results["annual"]
    for era, color in enumerate(ERAS):
        block = values[era * 21:(era + 1) * 21]
        years = [item["year"] for item in block]
        rates = [100 * item["k"] / item["n"] for item in block]
        ax.plot(years, rates, color=color, lw=.8, marker="o", ms=2.2)
        ax.hlines(results["primary"]["rates_pct"][era], years[0], years[-1], colors=color,
                  linestyles="--", linewidth=.8)
    ax.axvline(2002.5, color="#a5b2ae", lw=.65)
    ax.set(xlim=(1981, 2024), ylim=(0, None), xticks=(1982, 2002, 2023),
           xlabel="Season", ylabel="≥30-kt windows (%)")
    ax.yaxis.set_major_locator(MaxNLocator(4))
    axes_style(ax)
    panel(ax, "f", "Season-to-season variation")


def context_matrix(ax, result):
    support = np.array(result["support"])
    n = np.asarray(result["context_n"])
    k = np.asarray(result["context_k"])
    pool = (n / n.sum(axis=1, keepdims=True)).mean(axis=0)
    differences = 100 * (k[1] / n[1] - k[0] / n[0])
    grid = np.zeros((6, 4))
    weights = np.zeros_like(grid)
    for band in range(6):
        for v in range(4):
            group = ((support // 8) == band) & ((support % 4) == v)
            if group.any():
                grid[band, v] = np.average(differences[group], weights=pool[group])
                weights[band, v] = pool[group].sum()
    palette = LinearSegmentedColormap.from_list("changes", (EARLY, "#c6cbc3", LATE))
    norm = Normalize(-max(abs(grid.min()), grid.max()), max(abs(grid.min()), grid.max()))
    for row in range(6):
        if row % 2 == 0:
            ax.axhspan(row - .5, row + .5, color="#f0f4f3", zorder=0)
    for boundary in (1.5, 3.5):
        ax.axhline(boundary, color="#c5d2d1", lw=.55, zorder=1)
    for boundary in (.5, 1.5, 2.5):
        ax.axvline(boundary, color="#dce4e2", lw=.45, zorder=1)
    for i, row in enumerate(grid):
        for j, value in enumerate(row):
            if weights[i, j]:
                ax.scatter(j - .27, i, s=61 * weights[i, j] / weights.max(), color=palette(norm(value)),
                           lw=.38, edgecolor="#778783", zorder=2)
                label = f"{value:+.1f}".replace("-", "−")
            else:
                label = "—"
            ax.text(j + .35, i, label, fontsize=6, color=INK, ha="right", va="center")
    ax.set(xlim=(-.5, 3.5), ylim=(5.5, -.5))
    ax.set_xticks(range(4), ["35–49", "50–64", "65–79", "80–85"])
    ax.set_yticks(range(6), ["W · S", "W · N", "C · S", "C · N", "E · S", "E · N"])
    ax.tick_params(length=0, pad=3, labelsize=6)
    ax.set_xlabel("Starting wind (kt)", labelpad=3)
    ax.spines[:].set_visible(False)
    ax.text(0, -.40, "S/N split at 25°N · values in pp · circle area shows mean share of starts", transform=ax.transAxes,
            fontsize=5.6, color=MUTED)
    panel(ax, "e", "Change and representation within starting contexts")


def draw_interval(ax, value, interval, y, color, marker):
    ax.hlines(y, *interval, color=color, lw=.95)
    ax.plot([value], [y], marker=marker, color=color, ms=3.7, ls="none", zorder=3)


def decomposition(ax, result):
    values, intervals = result["effects_pp"], result["intervals_pp"]
    for row, (value, interval, color) in enumerate(zip(values, intervals, (INK, WITHIN, MIX), strict=True)):
        draw_interval(ax, value, interval, row, color, ("o", "s", "D")[row])
        ax.annotate(f"{value:+.2f}", (value, row), xytext=(0, 7), textcoords="offset points",
                    fontsize=6.0, ha="center", color=INK)
    ax.axvline(0, color="#516965", lw=.65, ls="--")
    ax.set(yticks=(0, 1, 2), yticklabels=("Total", "Within", "Mix"), ylim=(2.55, -.60),
           xlim=(-3.6, 4.0), xticks=(-3, -2, -1, 0, 1, 2, 3, 4), xlabel="Late minus early (pp)")
    ax.tick_params(axis="y", length=0)
    axes_style(ax, "x")
    panel(ax, "d", "Decomposition at 30 kt")


def save_fig(figure, file, title):
    figure.savefig(OUT / f"{file}.pdf", metadata={"Title": title, "CreationDate": None, "ModDate": None})
    figure.savefig(OUT / f"{file}.svg", metadata={"Title": title, "Date": None})
    plt.close(figure)
    with pymupdf.open(OUT / f"{file}.pdf") as source:
        page = source[0]
        pix = page.get_pixmap(matrix=pymupdf.Matrix(2400 / page.rect.width, 2400 / page.rect.width), alpha=False)
        Image.frombytes("RGB", (pix.width, pix.height), pix.samples).save(
            OUT / f"{file}.webp", "WEBP", quality=91, method=6
        )


def main_plate(results, data, land):
    fig = plt.figure(figsize=(183 / 25.4, 144 / 25.4))
    trajectory_map(fig.add_axes((.066, .580, .553, .303)), land, data, results["primary"])
    gain_bands(fig.add_axes((.722, .605, .264, .278)), results)
    threshold_profile(fig.add_axes((.066, .323, .553, .177)), results)
    decomposition(fig.add_axes((.722, .323, .264, .177)), results["primary"])
    context_matrix(fig.add_axes((.066, .092, .553, .135)), results["primary"])
    seasons(fig.add_axes((.722, .092, .264, .135)), results)
    heading = "Atlantic intensification across wind-gain thresholds"
    fig.text(.066, .989, heading, fontsize=11.6, ha="left", va="top", weight="bold")
    fig.text(.066, .950, "6,017 comparable 24-hour windows · 42 seasons · NOAA NHC HURDAT2",
             color=MUTED, fontsize=6.5, va="top")
    fig.add_artist(plt.Line2D([.066, .986], [.921, .921], transform=fig.transFigure, color="#aac0be", lw=.5))
    fig.text(.066, .022, "Dots mark starts in a. Lambert conformal conic projection. Land from Natural Earth. pp, percentage points.",
             fontsize=5.6, color=MUTED)
    save_fig(fig, "figure", heading)


def spec_forest(ax, results, keys):
    for row, key in enumerate(keys):
        result = results[key]
        for index, color, mark, shift in ((0, INK, "o", -.115), (1, WITHIN, "s", .115)):
            draw_interval(ax, result["effects_pp"][index], result["intervals_pp"][index], row + shift, color, mark)
    ax.axvline(0, color="#6d7c77", lw=.7, ls=":")
    ax.set_yticks(range(len(keys)), [LABELS[key] for key in keys])
    ax.set(ylim=(len(keys) - .46, -.54), xlim=(-5.4, 7.1), xticks=(-4, -2, 0, 2, 4, 6),
           xlabel="Late minus early (pp)")
    ax.tick_params(axis="y", length=0)
    axes_style(ax, "x")


def robustness_plate(results):
    fig, ax = plt.subplots(2, 2, figsize=(183 / 25.4, 126 / 25.4))
    fig.subplots_adjust(left=.126, right=.98, bottom=.105, top=.889, wspace=.39, hspace=.55)
    variants = ["primary", "utc00", "water", "allow_td", "wind95"]
    spec_forest(ax[0, 0], results, variants)
    panel(ax[0, 0], "a", "Changes to cohort eligibility")
    spec_forest(ax[0, 1], results, ["threshold25", "primary", "threshold35"])
    ax[0, 1].set_yticklabels(["25 kt", "30 kt", "35 kt"])
    handles = [plt.Line2D([0], [0], marker=mark, color=color, ls="", ms=3.5, label=label)
               for color, mark, label in ((INK, "o", "Total"), (WITHIN, "s", "Within context"))]
    ax[0, 1].legend(handles=handles, loc="upper right", frameon=False, handletextpad=.18)
    panel(ax[0, 1], "b", "Outcome definition")

    coverage = ax[1, 0]
    tick = np.arange(len(variants))
    for era, color in enumerate(ERAS):
        fractions = [100 * results[key]["windows"][era] / results[key]["eligible"][era] for key in variants]
        coverage.barh(tick + (era - .5) * .28, fractions, height=.24, color=color, alpha=.88,
                      label=("1982–2002", "2003–2023")[era])
    coverage.set_yticks(tick, [LABELS[key] for key in variants])
    coverage.set(xlim=(0, 104), ylim=(len(variants) - .48, -.53), xticks=(0, 25, 50, 75, 100),
                 xlabel="Eligible windows retained (%)")
    coverage.tick_params(axis="y", length=0)
    axes_style(coverage, "x")
    coverage.legend(loc="center right", bbox_to_anchor=(.985, .689), frameon=False, handlelength=.95,
                    handletextpad=.45, borderpad=.25, labelspacing=.5)
    panel(coverage, "c", "Coverage of shared contexts")

    omit = ax[1, 1]
    for index, color, mark in ((0, INK, "o"), (1, WITHIN, "s")):
        effect = results["primary"]["effects_pp"][index]
        omit.axhline(effect, color=color, lw=.7, ls="--")
        leave_out = results["omit_season"]
        omit.scatter([item["year"] for item in leave_out], [item["effects_pp"][index] for item in leave_out],
                     color=color, marker=mark, s=6, linewidths=0)
    omit.axhline(0, lw=.65, color="#a4b2ae")
    omit.set(xlim=(1981, 2024), xticks=(1982, 1992, 2002, 2012, 2023),
             xlabel="Season omitted", ylabel="Difference (pp)")
    omit.yaxis.set_major_locator(MaxNLocator(4))
    axes_style(omit)
    panel(omit, "d", "Influence of individual seasons")
    fig.text(.126, .979, "Sensitivity to eligibility, threshold and season", fontsize=7,
             weight="bold", va="top")
    fig.text(.126, .942, "Whole-season bootstrap intervals in a–b; fixed-support exclusions in d",
             fontsize=6.2, color=MUTED, va="top")
    save_fig(fig, "checks", "Sensitivity to eligibility, threshold and season")


def main():
    stats = json.loads((OUT / "results.json").read_bytes())
    data = np.load(OUT / "windows.npz")["selected"]
    land = coast_polygons()
    main_plate(stats, data, land)
    robustness_plate(stats)


if __name__ == "__main__":
    main()
