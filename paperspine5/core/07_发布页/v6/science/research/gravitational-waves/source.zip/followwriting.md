# Full Workflow and Skills Pack handoffs

The native host read the installed beta.2 Full Workflow entry and bundled methods, and opened the separate installed Pack entries for Study, Followwriting, Figures, Review and Delivery. The same public records and numerical evidence passed between modes. These are workflows over one analysis, not independent scientific replications. The primary study path produced the current manuscript identity and retained draft; the separate Pack entry points loaded the underlying artifacts and guided presentation, review and final files. The installed manager returned offline preflight for all three local profiles and continued on beta.2.

| Entry | Input read | Output |
| --- | --- | --- |
| Full Workflow / Study | GWOSC v3 event metadata and four HDF5 records, discovery papers, fixed protocol | Protocol and analyzer; results and display arrays; complete first draft |
| Followwriting | Study evidence and original source passages below | Independent argument in draft.tex; later interpretation and Results changes in paper.tex |
| Figures | Native strain display arrays, all nine score/lag settings, cited figure-caption anchors | Main merger-strain and secondary lag-sensitivity SVGs, PDFs, PNGs, WebPs and captioned paper |
| Review | Initial rendered manuscript, figures, nine-setting measured outputs and saved UI feedback | Reduced page overflow, improved panel spacing, retained first draft, clarified diagnostic controls and timing spread |
| Delivery | Revised TeX and plot PDFs | Five-page paper, SVGs and independently extractable source ZIP |

## Reference moves

- Abbott et al. 2016, arXiv:1602.03837v1, physical p. 2, Fig. 1 and its caption. The original first establishes the event in each detector and then explains the alignment and polarity used for the overlay. We transferred the reader order from measured morphology to alignment, following it with an independent correlation-curve test. Original timing comes from the reference as external context; the +7.36 ms estimate and its display are from this run.
- Abbott et al. 2017, arXiv:1709.09660v3, physical pp. 1–2, Introduction and Fig. 1 caption. The original locates Hanford and Virgo timing relative to Livingston and states the noise scaling in its visual evidence. We retain Livingston as timing reference and define noise RMS in the caption. Its best-fit models, reconstruction uncertainty, three-detector inference and numerical figure contents do not enter this analysis.
- Abbott et al. 2021, arXiv:1912.11716v2, data products and quality overview, is the source for HDF5 release context. The original release data quality fields are inspected by the analyzer. No general accuracy claim is borrowed from the archive report.

Independent outline: fixed recorded inputs → specify the signed lag and time-shifted controls → show native-grid morphology before aligned overlay → show the complete signed lag curve → check preprocessing sensitivity and explain the restricted control interpretation. The source publications' structure, results and detector geometry inference were not copied.

## Located changes

- Figure 1 E/F: more separation below the middle x-axis label and alignment of energy colorbar to the spectrogram axes, based on actual 1,100-pixel and 350-pixel inspection.
- Results, second unit: expanded a statement of zero exceedances to give all four measured primary control maxima and describe reuse of 46 time offsets per detector. For known events in short extracts the comparison provides local context only.
- Results, timing: exchanged the initial direction-only sensitivity summary for the measured ranges (7.28–7.54 and 7.65–8.00 ms).
- Discussion: clarified why repeatedly using 46 offsets cannot calibrate a false-alarm probability or rate. Figure 1 caption now states that its off-source shading is descriptive.
- Delivery: tightened title/text spacing and fitted the revised Figure 1 and Results to one page. Verified all five page images, captions and the PDF text.

The writing and author checks were conducted by the native study agent. The supervisor independently viewed the first figure and requested spacing/colorbar changes. Browser interactions were performed in an isolated automated test session, as a test user. No journal submission, native slash-menu selection, or independent blinded manuscript review was performed.
