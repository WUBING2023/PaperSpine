from __future__ import annotations

import argparse
import json
from hashlib import file_digest
from pathlib import Path

import h5py
import numpy as np
from scipy import signal
from scipy.ndimage import median_filter

FS = 4096
EVENTS = ("GW150914", "GW170814")
DETECTORS = ("H1", "L1")
BANDS = ((35, 250), (30, 180), (45, 350))
PSDS = (("median", 1), ("mean", 1), ("median", 2))
LAGS = np.arange(-41, 42)
OFFSETS = np.concatenate((-np.arange(5, 28)[::-1], np.arange(5, 28))) / 4
FREQUENCIES = np.geomspace(32, 300, 94)
EVAL_TIME = np.arange(-1500, 610, 5) / FS


def digest(path):
    with path.open("rb") as handle:
        return file_digest(handle, "sha256").hexdigest()


def dataset(datadir, event):
    meta = datadir / (event + ".json")
    source = json.loads(meta.read_text(encoding="utf-8"))["events"][event + "-v3"]
    gps = source["GPS"]
    details = {"gps": gps, "metadata_url": source["jsonurl"], "metadata_sha256": digest(meta), "strain": {}}
    arrays = []
    for det in DETECTORS:
        entry, = [s for s in source["strain"] if s["detector"] == det and s["sampling_rate"] == FS
                  and s["duration"] == 32 and s["format"] == "hdf5"]
        path = datadir / f"{event}-{det}.hdf5"
        with h5py.File(path, "r") as data:
            ds = data["strain/Strain"]
            strain = ds[:]
            start = int(data["meta/GPSstart"][()])
            delta = ds.attrs["Xspacing"]
            dq = data["quality/simple/DQmask"][:]
        assert len(strain) == 32 * FS and delta == 1 / FS and np.isfinite(strain).all()
        assert start == entry["GPSstart"] and 14 < gps - start < 18
        assert len(dq) == 32 and np.all(dq[(np.arange(32) + 1 > gps-start-14) & (np.arange(32) < gps-start+14)] & 1)
        arrays.append(strain)
        details["strain"][det] = {"url": entry["url"], "sha256": digest(path), "gps_start": start,
                                  "data_bits": sorted({int(x) for x in dq})}
    assert details["strain"]["H1"]["gps_start"] == details["strain"]["L1"]["gps_start"]
    time = np.arange(32 * FS) / FS - (gps - start)
    return time, arrays, details


def whiten(time, strain, psd, padding):
    aggregate, seconds = psd
    length = seconds * FS
    training = [strain[(time >= lo) & (time < hi)] for lo, hi in [(-14, -8), (8, 14)]]
    periodograms = []
    for y in training:
        f, _, ps = signal.spectrogram(y, fs=FS, window="hann", nperseg=length,
                                      noverlap=length//2, detrend="constant", mode="psd")
        periodograms.append(ps)
    pool = np.concatenate(periodograms, axis=1)
    reduce = np.median if aggregate == "median" else np.mean
    density = reduce(pool, axis=1)
    # 3-bin median on log scale limits interpolation sensitivity to single-bin troughs.
    log_psd = median_filter(np.log(np.maximum(density, np.finfo(float).tiny)), size=3)
    n = padding * FS
    y = np.pad(signal.windows.tukey(len(strain), 0.125) * (strain - np.mean(strain)), n)
    fft_f = np.fft.rfftfreq(len(y), 1 / FS)
    w = np.exp(-np.interp(fft_f, f, log_psd) / 2)
    return np.fft.irfft(np.fft.rfft(y) * w, n=len(y)), n


def band_pass(y, padding, band):
    sos = signal.butter(4, band, btype="bandpass", fs=FS, output="sos")
    return signal.sosfiltfilt(sos, y, padtype="odd")[padding:-padding]


def window_indices(time):
    return np.flatnonzero((time >= -0.16) & (time < 0.09))


def curve(h, l, indices, h_slide=0, l_slide=0):
    a = h[indices + h_slide]
    b = l[indices[None, :] + l_slide - LAGS[:, None]]
    a = a - np.mean(a)
    b = b - np.mean(b, axis=1, keepdims=True)
    return (b @ a) / (np.linalg.norm(a) * np.linalg.norm(b, axis=1))


def peak(y):
    z = np.abs(y)
    i = int(np.argmax(z))
    shift = 0.0
    if 0 < i < len(LAGS) - 1:
        x0, x1, x2 = z[i-1:i+2]
        denominator = x0 - 2*x1 + x2
        if denominator < 0:
            shift = (x0 - x2) / (2 * denominator)
    return {"lag_ms": float(1000 * (LAGS[i] + shift) / FS), "lag_samples_grid": int(LAGS[i]),
            "rho": float(y[i]), "edge": i in (0, len(LAGS)-1)}


def control_curves(h, l, indices):
    offsets = (OFFSETS * FS).astype(int)
    h_mat = h[indices + offsets[:, None]]
    l_mat = l[indices[None, None, :] + offsets[:, None, None] - LAGS[None, :, None]]
    h_mat = h_mat - np.mean(h_mat, axis=1, keepdims=True)
    l_mat = l_mat - np.mean(l_mat, axis=2, keepdims=True)
    h_mat /= np.linalg.norm(h_mat, axis=1, keepdims=True)
    l_mat /= np.linalg.norm(l_mat, axis=2, keepdims=True)
    full = h_mat @ l_mat.reshape(-1, len(indices)).T
    full = full.reshape(len(offsets), len(offsets), len(LAGS))
    off = full[np.arange(len(offsets)), np.arange(len(offsets))]
    slide = full[np.sign(offsets[:, None]) != np.sign(offsets[None, :])]
    return off, slide


def energy_map(y, time):
    center = np.rint((EVAL_TIME - time[0]) * FS).astype(int)
    control_centers = (OFFSETS * FS).astype(int)[:, None] + center
    power = []
    for f in FREQUENCIES:
        std = 5.0 / (2 * np.pi * f)
        radius = int(np.ceil(4 * std * FS))
        dt = np.arange(-radius, radius + 1) / FS
        kernel = np.exp(-0.5*(dt/std)**2 + 2j*np.pi*f*dt)
        conv = signal.fftconvolve(y, kernel, mode="same")
        valid = abs(conv)**2
        power.append(valid[center] / np.median(valid[control_centers]))
    return np.array(power)


def validate(estimator_time):
    x = np.arange(8192) / FS - 1
    y = signal.chirp(x, 55, 0.2, 112) * np.exp(-(x/0.085)**2)
    for delay in [7.35, -11.60, 39.8]:
        t = x + delay / FS
        l = -signal.chirp(t, 55, 0.2, 112) * np.exp(-(t/0.085)**2)
        result = peak(curve(y, l, window_indices(x)))
        assert result["rho"] < -0.999 and abs(result["lag_ms"] * FS / 1000 - delay) < 0.025
    assert peak(np.linspace(0.0, 1.0, len(LAGS)))["edge"]
    assert len(estimator_time) == 1024


def analyze(data, out):
    out.mkdir(exist_ok=True, parents=True)
    results, plot = {}, {}
    for event in EVENTS:
        time, raw, details = dataset(data, event)
        indices = window_indices(time)
        validate(indices)
        projection = {"sources": details, "settings": []}
        for psd in PSDS:
            w = [whiten(time, strain, psd, 4) for strain in raw]
            for band in BANDS:
                h, l = [band_pass(*y, band) for y in w]
                e = curve(h, l, indices)
                off, slide = control_curves(h, l, indices)
                sync, shifted = np.abs(off).max(axis=1), np.abs(slide).max(axis=1)
                measured = peak(e)
                result = {"band": band, "psd": psd, **measured,
                          "offsource_maxabs": sync.tolist(), "slide_maxabs": shifted.tolist(),
                          "offsource_ge": int(np.sum(sync >= abs(measured["rho"]))),
                          "slide_ge": int(np.sum(shifted >= abs(measured["rho"]))),
                          "top_offsource": float(max(sync)), "top_slide": float(max(shifted))}
                projection["settings"].append(result)
                if band == BANDS[0] and psd == PSDS[0]:
                    extended = [band_pass(*whiten(time, s, psd, 8), band) for s in raw]
                    verify = peak(curve(*extended, indices))
                    projection["padding_check"] = {"lag_delta_ms": verify["lag_ms"] - measured["lag_ms"],
                                                    "rho_delta": verify["rho"] - measured["rho"]}
                    show = (time >= -0.36) & (time <= 0.15)
                    aligned = np.interp(time[show] - measured["lag_ms"]/1000, time, l)
                    # Show both traces in each series' local noise RMS.
                    scale = [np.std(z[(np.abs(time) >= 1.25) & (np.abs(time) <= 6.75)]) for z in (h, l)]
                    pair = np.diag(np.reciprocal(scale)) @ np.asarray([h[show], aligned*np.sign(measured["rho"])])
                    plot[event+"-energy"] = 10*np.log10((energy_map(h,time) + energy_map(l,time))/2)
                    plot[event+"-time"] = time[show]
                    plot[event+"-strain"] = pair
                    plot[event+"-corr"] = e
                    plot[event+"-off-corr"] = off
        results[event] = projection
        base = projection["settings"][0]
        print(event, base["lag_ms"], base["rho"], base["offsource_ge"], base["slide_ge"], projection["padding_check"], flush=True)
    (out/"results.json").write_text(json.dumps(results, indent=2)+"\n", encoding="utf-8")
    np.savez_compressed(out/"plot-data.npz", **plot)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--out", type=Path, default=Path("results"))
    args = parser.parse_args()
    analyze(args.data, args.out)
