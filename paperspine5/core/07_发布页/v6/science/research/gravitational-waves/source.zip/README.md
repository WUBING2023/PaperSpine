# Two black-hole mergers in public LIGO strain

This reproducibility bundle reanalyzes the 32-second H1 and L1 strain excerpts for GW150914 and GW170814 from the Gravitational Wave Open Science Center (GWOSC). Full provenance, including file checksums, appears in `results/results.json`. Each known event is characterized across nine prespecified conditioning choices. The time-slide scores have dependent inputs and provide a local descriptive comparison.

## Reproduce the analysis

Use Python 3.12 with NumPy, SciPy, h5py, Matplotlib and Pillow. From the extracted folder, run `python download.py`, `python analyze.py`, and `python plot.py`. The download script verifies all four retrieved HDF5 SHA-256 values and reads the included versioned event JSON. Original HDF5 files are hosted by GWOSC. If the four HDF5 files are already available, place them in `data/` with names of the form `GW150914-H1.hdf5`, and skip the download.

The final `paper.tex` uses the adjacent `merger-strain.pdf` and `lag-sensitivity.pdf`. Run `pdflatex -interaction=nonstopmode -halt-on-error paper.tex` twice. Editable SVGs contain vector text and trajectories with a rasterized measured intensity layer. The NPZ contains only derived figure arrays and can be used to regenerate graphics without re-downloading strain.

## Sources

[GWTC-1 strain release](https://doi.org/10.7935/82H3-HH23) · [GW150914 paper](https://doi.org/10.1103/PhysRevLett.116.061102) · [GW170814 paper](https://doi.org/10.1103/PhysRevLett.119.141101) · [Open-data methods](https://doi.org/10.1016/j.softx.2021.100658)

The versioned event data are available under CC BY 4.0 from GWOSC. The paper includes the GWOSC attribution.
