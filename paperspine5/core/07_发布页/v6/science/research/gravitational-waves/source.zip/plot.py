from pathlib import Path
import json
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import NullFormatter
import numpy as np
from PIL import Image
from analyze import EVENTS, EVAL_TIME, FREQUENCIES, LAGS, FS

ROOT=Path(__file__).resolve().parent
DATA=np.load(ROOT/'results/plot-data.npz')
RESULTS=json.loads((ROOT/'results/results.json').read_text())
INK='#172335'
SOFT='#546477'
GRID='#d7e1e8'
PAPER='#fcfcfa'
H1='#087b82'
L1='#c05731'
BG='#10182b'
PALETTE=LinearSegmentedColormap.from_list('ember', ['#12182a','#252f55','#3f5c87','#6197a5','#a6cac0','#f5d79c','#fff3cc'])
mpl.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelcolor':INK,
                     'xtick.color':INK,'ytick.color':INK,'axes.edgecolor':GRID,
                     'svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':True})


def label(ax, x, y, text, **kw):
    ax.text(x,y,text,transform=ax.transAxes,**kw)


def base_axis(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.tick_params(length=3,width=.7,pad=3,labelsize=9)
    ax.set_axisbelow(True)
    ax.grid(axis='y',color=GRID,linewidth=.6)


def output(fig, stem):
    for ext in ['svg','pdf']:
        fig.savefig(ROOT/f'{stem}.{ext}',facecolor=PAPER,dpi=300)
    png=ROOT/f'{stem}.png'
    fig.savefig(png,facecolor=PAPER,dpi=230)
    with Image.open(png) as im:
        im.convert('RGB').save(ROOT/f'{stem}.webp',quality=93)
        im.thumbnail((350,350), Image.Resampling.LANCZOS)
        im.save(ROOT/f'{stem}-350.png')
    plt.close(fig)


def main_figure():
    fig=plt.figure(figsize=(11.4,7.0),facecolor=PAPER)
    fig.text(.091,.94,'Two black-hole mergers in public LIGO strain',color=INK,fontsize=21,weight='bold')
    fig.text(.091,.897,'Hanford and Livingston · 35–250 Hz primary analysis',color=SOFT,fontsize=11)
    grid=fig.add_gridspec(3,2,left=.095,right=.875,bottom=.105,top=.805,wspace=.15,hspace=.59,
                         height_ratios=(2.1,1.1,1.16))
    for i,event in enumerate(EVENTS):
        ax=fig.add_subplot(grid[0,i])
        result=RESULTS[event]['settings'][0]
        edge=(-160,90)
        im=ax.pcolormesh(EVAL_TIME*1000,FREQUENCIES,DATA[event+'-energy'],cmap=PALETTE,
                         vmin=-5,vmax=17,shading='nearest',rasterized=True)
        ax.set_yscale('log')
        ax.set(ylim=(36,245),xlim=(-320,130))
        ax.set_yticks([40,60,100,160,240],labels=[40,60,100,160,240])
        ax.yaxis.set_minor_formatter(NullFormatter())
        ax.tick_params(which='minor',length=0)
        ax.axvline(0,color='white',alpha=.44,lw=.7,ls='--')
        for v in edge: ax.axvline(v,color='white',alpha=.48,lw=.65)
        ax.tick_params(labelbottom=False,labelleft=i==0,length=2,labelsize=9)
        if i==0: ax.set_ylabel('Frequency (Hz)')
        label(ax,0,1.075,('A' if i==0 else 'B')+'   '+event,color=INK,fontsize=14,weight='bold')
        label(ax,1,1.075,'2015 Sep 14' if i==0 else '2017 Aug 14',ha='right',color=SOFT,fontsize=9)
        ax=fig.add_subplot(grid[1,i],sharex=ax)
        base_axis(ax)
        ax.axvspan(*edge,color='#e5eef0',lw=0)
        ax.axvline(0,color=SOFT,alpha=.55,lw=.7,ls='--')
        h,l=DATA[event+'-strain'];time=DATA[event+'-time']*1000
        ax.plot(time,h,color=H1,lw=1.55,label='H1')
        ax.plot(time,l,color=L1,lw=1.2,label='L1 aligned, inverted',alpha=.93)
        ax.set(ylim=(-6.8,6.8),yticks=[-5,0,5],xlim=(-320,130))
        ax.set_xticks([-300,-200,-100,0,100])
        ax.set_xlabel('Time from catalog GPS (ms)',labelpad=3,fontsize=9)
        if i==0: ax.set_ylabel('Noise RMS')
        else: ax.tick_params(labelleft=False)
        label(ax,0,1.07,('C' if i==0 else 'D')+'   Aligned strain',weight='bold',color=INK)
        if i==0:
            ax.legend(frameon=False,loc='lower left',bbox_to_anchor=(.38,1.00),ncol=2,
                      columnspacing=.6,handlelength=1.0,handletextpad=.35,fontsize=7.7)
        ax=fig.add_subplot(grid[2,i])
        base_axis(ax)
        lag=LAGS*1000/FS
        off=DATA[event+'-off-corr']
        a,b=np.quantile(off,[.05,.95],axis=0)
        ax.fill_between(lag,a,b,color='#cedde7',linewidth=0,label='Off-source 5–95%')
        ax.axhline(0,color=SOFT,lw=.7,alpha=.6)
        ax.plot(lag,DATA[event+'-corr'],color=INK,lw=1.55)
        ax.scatter(result['lag_ms'],result['rho'],s=22,color=L1,zorder=4)
        ax.axvline(result['lag_ms'],color=L1,lw=.8,ls=':')
        ax.set(xlim=(-10.01,10.01),ylim=(-.82,.55),yticks=[-.5,0,.5],xticks=[-10,-5,0,5,10])
        ax.set_xlabel('Lag H1 − L1 (ms)',labelpad=3,fontsize=9)
        if i==0: ax.set_ylabel('Correlation')
        else: ax.tick_params(labelleft=False)
        label(ax,0,1.08,('E' if i==0 else 'F')+'   Similarity across lags',weight='bold',color=INK)
        label(ax,.98,1.08,f"+{result['lag_ms']:.2f} ms",ha='right',color=L1,weight='bold')
        if i==0:
            ax.legend(frameon=False,loc='upper left',fontsize=7.5,handlelength=1.0)
    spectral=fig.axes[0].get_position()
    c=fig.add_axes((.902,spectral.ymin,.015,spectral.height))
    bar=fig.colorbar(im,cax=c,ticks=[-5,0,5,10,15])
    bar.outline.set_visible(False)
    bar.ax.tick_params(labelsize=9,length=2)
    bar.set_label('Relative energy (dB)',fontsize=9,labelpad=7)
    output(fig,'merger-strain')


def settings_figure():
    fig=plt.figure(figsize=(11.4,4.9),facecolor=PAPER)
    fig.text(.09,.925,'Lag sensitivity across nine conditioning choices',fontsize=20,color=INK,weight='bold')
    fig.text(.09,.865,'All estimates use the same 250 ms event window and ±10.01 ms search',fontsize=11,color=SOFT)
    gs=fig.add_gridspec(1,2,left=.265,right=.92,bottom=.17,top=.74,wspace=.49,width_ratios=[1,1.1])
    ax=fig.add_subplot(gs[0,0]); bx=fig.add_subplot(gs[0,1])
    for a in [ax,bx]:
        base_axis(a);a.set_ylim(8.7,-.7);a.set_yticks(range(9))
        a.axhspan(-.46,.46,color='#e5eef0',lw=0)
    settings=RESULTS[EVENTS[0]]['settings']
    text=[f"{r['band'][0]}–{r['band'][1]} Hz  /  {r['psd'][0]} {r['psd'][1]} s" for r in settings]
    ax.set_yticklabels(text)
    bx.set_yticklabels([])
    ax.set(xlabel='Peak lag H1 − L1 (ms)',title='A   Peak timing')
    bx.set(xlabel='Absolute peak correlation',title='B   Event vs. local controls',xlim=(.14,.84))
    for idx,(event,color) in enumerate(zip(EVENTS,[H1,L1])):
        r=RESULTS[event]['settings']
        y=np.arange(9)+(idx-.5)*.22
        ax.plot([s['lag_ms'] for s in r],y,color=color,lw=.75,alpha=.5)
        ax.scatter([s['lag_ms'] for s in r],y,s=28,color=color,label=event)
        for i,s in enumerate(r):
            quant, upper=np.quantile(s['slide_maxabs'],[.5,.95])
            bx.plot([quant,upper],[y[i],y[i]],color=color,lw=2.6,alpha=.34)
            bx.scatter(upper,y[i],s=20,marker='|',color=color,alpha=.8)
        bx.scatter([abs(s['rho']) for s in r],y,s=28,color=color)
    ax.legend(frameon=False,loc='lower right',bbox_to_anchor=(1.0,1.055),ncol=2,
              handletextpad=.25,columnspacing=.65,fontsize=9)
    fig.text(.606,.04,'Bars show median to 95th percentile for time slides.',fontsize=8.5,color=SOFT)
    output(fig,'lag-sensitivity')


if __name__=='__main__':
    main_figure()
    settings_figure()
