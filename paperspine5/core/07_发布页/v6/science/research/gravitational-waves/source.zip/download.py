from hashlib import sha256
from pathlib import Path
import json
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
results = json.loads((ROOT/'results/results.json').read_text(encoding='utf-8'))
for event, result in results.items():
    for detector, source in result['sources']['strain'].items():
        out = ROOT/'data'/f'{event}-{detector}.hdf5'
        if out.exists():
            raw = out.read_bytes()
        else:
            with urlopen(source['url'], timeout=40) as response:
                raw = response.read()
        if sha256(raw).hexdigest() != source['sha256']:
            raise ValueError(f'SHA-256 mismatch for {out.name}')
        if not out.exists():
            out.write_bytes(raw)
        print(f'{out.name} verified')
