"""Render a two-panel, font-editable SVG plus a publication PDF from saved results."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np


RUN = Path(__file__).resolve().parent
INK = "#1b293b"
MUTED = "#47576c"
RAW = "#4e5d75"
SCALED = "#006c6a"
CHANGE = "#c0cddb"
GRID = "#e0e7ef"


def paired_axes(ax, y, raw, scaled, xlim, ticks, row_names):
    ax.hlines(y, raw, scaled, color=CHANGE, linewidth=1.5, zorder=2)
    ax.scatter(raw, y, s=23, color="white", edgecolors=RAW, linewidths=1.2, zorder=3)
    ax.scatter(scaled, y, s=22, color=SCALED, edgecolors=SCALED, marker="D", linewidths=0.5, zorder=3)
    ax.set_xticks(ticks)
    ax.set_yticks(y, row_names)
    ax.set_xlim(xlim)
    ax.set_ylim(len(y) - 0.5, -0.5)
    ax.xaxis.grid(True, color=GRID, linewidth=0.7, zorder=0)
    ax.spines[["top", "left", "right"]].set_visible(False)
    ax.spines["bottom"].set_color(CHANGE)
    ax.tick_params(axis="y", length=0, pad=7)
    ax.tick_params(axis="x", length=3, color=CHANGE)


def main():
    result = json.loads((RUN / "01-results.json").read_text(encoding="utf-8"))
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8, "text.color": INK,
        "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
        "svg.fonttype": "none", "svg.hashsalt": "dry-bean-knn-scaling", "pdf.fonttype": 42,
    })
    fig = plt.figure(figsize=(7.45, 3.25), facecolor="white")
    grid = fig.add_gridspec(1, 2, left=0.104, right=0.979, bottom=0.22, top=0.757, wspace=0.48)
    left, right = fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])
    folds = result["folds"]
    paired_axes(left, np.arange(len(folds)), [100 * row["raw"] for row in folds],
                [100 * row["scaled"] for row in folds], (68, 100), [70, 80, 90, 100],
                [f'Fold {row["fold"]}' for row in folds])
    left.set_xlabel("Balanced accuracy (%)", labelpad=5)
    left.set_title("A   Five paired folds", loc="left", fontweight="bold", fontsize=10, pad=10)

    recalls = result["out_of_fold_class_recall"]
    paired_axes(right, np.arange(len(result["class_labels"])), 100 * np.array(recalls["raw"]),
                100 * np.array(recalls["scaled"]), (45, 103), [50, 60, 70, 80, 90, 100],
                [name.title() for name in result["class_labels"]])
    right.set_xlabel("Pooled held-out recall (%)", labelpad=5)
    right.set_title("B   Recall by variety", loc="left", fontweight="bold", fontsize=10, pad=10)
    fig.legend(handles=[
        Line2D([0], [0], color=RAW, linestyle="none", marker="o", markerfacecolor="white", markersize=5,
               label="Original measurement scales"),
        Line2D([0], [0], color=SCALED, linestyle="none", marker="D", markersize=4.3,
               label="Training-fold z-scores"),
    ], loc="upper left", bbox_to_anchor=(0.08, 0.99), frameon=False, ncols=2, columnspacing=2.3)
    fig.savefig(RUN / "fig-01.svg", metadata={"Date": None, "Title": "Paired Dry Bean evaluation"})
    fig.savefig(RUN / "fig-01.pdf", metadata={"CreationDate": None, "Title": "Paired Dry Bean evaluation"})
    fig.savefig(RUN / "fig-01.png", dpi=260)
    plt.close(fig)


if __name__ == "__main__":
    main()
