"""Recompute the paired Dry Bean comparison without writing the input dataset."""

import argparse
from hashlib import sha256
import io
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from scipy.io import arff
import sklearn
from sklearn.metrics import balanced_accuracy_score, confusion_matrix
from sklearn.model_selection import StratifiedKFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits


RUN = Path(__file__).resolve().parent
MEMBER = "data/Dry_Bean_Dataset.arff"
ARMS = ("raw", "scaled")


def read_data(source):
    if source.suffix.lower() == ".arff":
        return source.read_bytes()
    with ZipFile(source) as archive:
        return archive.read(MEMBER)


def parse_data(contents):
    rows, meta = arff.loadarff(io.StringIO(contents.decode("utf-8-sig")))
    features = meta.names()[:-1]
    x = np.column_stack([rows[name] for name in features]).astype(np.float64)
    labels = np.char.decode(rows[meta.names()[-1]].astype("S"), encoding="ascii")
    if x.shape != (13_611, 16) or len(np.unique(labels)) != 7 or not np.isfinite(x).all():
        raise ValueError("Unexpected dataset dimensions, labels or missing measurements")
    _, first_indices = np.unique(rows, return_index=True)
    kept = np.sort(first_indices)
    return x[kept], labels[kept], features, len(rows)


def classify(train, test, labels):
    model = KNeighborsClassifier(n_neighbors=7, weights="uniform", metric="euclidean", algorithm="brute", n_jobs=1)
    return model.fit(train, labels).predict(test)


def run(contents):
    x, y, features, original_rows = parse_data(contents)
    classes, counts = np.unique(y, return_counts=True)
    predictions = {arm: np.empty_like(y) for arm in ARMS}
    fold_assignment = np.zeros(y.size, dtype=np.uint8)
    scores = []
    splits = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    with threadpool_limits(limits=1):
        for fold, (train, test) in enumerate(splits.split(x, y), 1):
            scaler = StandardScaler().fit(x[train])
            predictions["raw"][test] = classify(x[train], x[test], y[train])
            predictions["scaled"][test] = classify(scaler.transform(x[train]), scaler.transform(x[test]), y[train])
            fold_assignment[test] = fold
            scores.append({
                "fold": fold,
                "test_n": int(test.size),
                **{arm: balanced_accuracy_score(y[test], predictions[arm][test]) for arm in ARMS},
            })
    for score in scores:
        score["difference_pp"] = 100 * (score["scaled"] - score["raw"])
    confusion = {arm: confusion_matrix(y, guesses, labels=classes) for arm, guesses in predictions.items()}
    class_recall = {arm: matrix.diagonal() / counts for arm, matrix in confusion.items()}
    return {
        "dataset_doi": "10.24432/C50S4B",
        "arff_sha256": sha256(contents).hexdigest(),
        "original_rows": original_rows,
        "unique_rows": int(y.size),
        "duplicate_rows_omitted": int(original_rows - y.size),
        "conflicting_label_feature_rows": int(y.size - np.unique(x, axis=0).shape[0]),
        "feature_names": features,
        "class_labels": classes.tolist(),
        "class_n": counts.tolist(),
        "scikit_learn": sklearn.__version__,
        "fold_assignment_sha256": sha256(fold_assignment.tobytes()).hexdigest(),
        "folds": scores,
        "mean_balanced_accuracy": {arm: float(np.mean([score[arm] for score in scores])) for arm in ARMS},
        "mean_difference_pp": float(np.mean([score["difference_pp"] for score in scores])),
        "out_of_fold_class_recall": {arm: vals.tolist() for arm, vals in class_recall.items()},
        "out_of_fold_confusion": {arm: matrix.tolist() for arm, matrix in confusion.items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="UCI .arff or archive containing the project provenance input")
    parser.add_argument("--output", type=Path, default=RUN / "01-results.json")
    args = parser.parse_args()
    result = run(read_data(args.input))
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f'{result["unique_rows"]:,} rows, five folds, {result["mean_difference_pp"]:+.4f} pp')


if __name__ == "__main__":
    main()
