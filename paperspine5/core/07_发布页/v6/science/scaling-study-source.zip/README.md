# PaperSpine V6 Skills Pack trial

One native Codex subagent took a new question on UCI Dry Bean through the published `6.0.0-beta.2` Skills Pack. The original ZIP matched release SHA-256 `059ccbdf2251321eecf8c1d726d387c62d14ed4244b9a33e0736059d07feeb88`. The shipped manager installed six Skills in a clean, isolated Codex home. Fresh `codex debug prompt-input` calls confirmed native catalog discovery from that home. The research subagent opened and followed those exact installed instructions, using files as inputs at each step.

This experiment retained 13,543 public records after exact deduplication. When a fixed 7-nearest-neighbor classifier used training-fold z-scores, mean balanced accuracy rose from **71.62% to 93.46%**, a **21.84 percentage-point** increase across five matched folds. Held-out Barbunya-to-Cali errors fell from 460 to 86. Dermason-to-Sira errors rose from 187 to 213. The estimate concerns this single internal benchmark. [Data source](https://doi.org/10.24432/C50S4B)

| Entry used | Input | Output |
| --- | --- | --- |
| `$paper-spine` | Question and source path | Task scope and local working files with bounded claims |
| `$paper-spine-study` | Public ARFF, source passages, fixed study design | [Protocol](01-study-protocol.md), [analysis](analyze.py), [measured results](01-results.json), [evidence notes](01-evidence.md) |
| `$paper-spine-followwriting` | Evidence notes and public original papers | [Reference-guided writing notes](02-followwriting.md), [retained draft](02-manuscript-draft.tex) |
| `$paper-spine-figures` | Saved per-fold results and class recalls | [Editable figure](fig-01.svg), [plot source](plot_results.py), [caption](fig-01-caption.md) |
| `$paper-spine-review` | Draft, figure and measured results | [Located findings and corrections](03-review.md) and the revised source |
| `$paper-spine-deliver` | Revised source and vector figure | [Reading PDF](dry-bean-scaling.pdf) and [editable TeX](dry-bean-scaling.tex) with its vector figure assets |

The subagent verified content and inspected both rendered pages after revision. The recorded review is by the authoring agent. The update endpoint was inaccessible inside this run's network sandbox. The installed manager returned `offline`, and the run used the installed beta.2 instructions. Auto-update activation and uninstall were outside this run.

## Rebuild

Keep `dry-bean-scaling.tex` beside `fig-01.pdf` and run `pdflatex -interaction=nonstopmode -halt-on-error dry-bean-scaling.tex` twice for resolved references. This run used TeX Live 2025. To regenerate the figure using the supplied results, run `python -B plot_results.py` from this folder with Matplotlib installed. The plot source generates SVG and PDF, as well as a preview PNG.

To repeat the measurements, obtain `Dry_Bean_Dataset.arff` from the UCI data download and pass it to `python -B analyze.py --input <path-to-arff> --output recomputed.json`. The verified copy's SHA-256 appears in `01-results.json`. The runtime used Python 3.12, scikit-learn 1.8.0, NumPy 2.2.6, SciPy 1.17.1 and Matplotlib 3.10.9. The original measured records remain in their authoritative location. This package contains only the study's aggregate results, code, and paper materials.
