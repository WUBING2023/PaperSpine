# Figure 1

Standardization improved held-out balanced accuracy in every paired fold. **A** Held-out balanced accuracy across seven varieties for the fixed 7-nearest-neighbor classifier. Each connector joins predictions for the same fold. **B** Variety-specific recall pooled across each row's one held-out prediction. Circles mark original measurement scales and diamonds mark z-scores computed with training-fold statistics. The plotted folds overlap in training data. Their spread describes split-to-split variation.

**Alt text.** Five balanced-accuracy pairs rise from around 72% to around 93%. Seven recall pairs all rise, with the largest increases for Barbunya and Seker. Bombay begins above 99% in both treatments.
