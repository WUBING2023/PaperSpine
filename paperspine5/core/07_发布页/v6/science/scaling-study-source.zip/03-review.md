# Manuscript review and revision

Scope. The Codex subagent who wrote `02-manuscript-draft.tex` conducted the check below after drafting. This was a same-agent pass. Parent review, if returned, will be identified separately. Scientific claims were checked against `01-results.json` and the opened primary material, and both draft pages were inspected after rendering.

| Location in the retained draft | Severity and evidence | Revision in `dry-bean-scaling.tex` |
| --- | --- | --- |
| Abstract, p. 1, “Most Barbunya-to-Cali errors disappeared” | Moderate. The two matched confusion cells are verifiable, and readers need the denominators to compare errors in unequal classes. | Replace the approximate assertion with 460 to 86 of 1,322, followed by the contrasting 187 to 213 of 3,546 for Dermason to Sira. Both counts are from pooled held-out predictions. |
| Paired Evaluation, p. 1, “standard deviation fitted on the training rows” and “averaged the scores” | Moderate. `StandardScaler` and `np.mean` resolve which variance and weighting conventions matter for reproducibility. | Specify the population standard deviation and the unweighted average of the five fold scores. State the separate pooling rule for recall. |
| Discussion, p. 2, “the aggregate improvement and the individual errors answer different questions” | Moderate. `analyze.py` changes all 16 weights together and therefore cannot identify a responsible subset. | Explain the meaning of the observed gain and replace the repeated error summary with a feature attribution limit. Retain the external validation boundary. |
| References, p. 2, visibly stretched lines in the original paper citation | Minor. The second draft page image exposes exaggerated word spacing in the citation. | Use left-aligned references and compile and inspect both pages again. |

Checks on the revised scope. The mean, per-fold range, recomputed confusion cells and lowest recall remain identical to the measured results. Figure axes use percentages, and the title distinguishes the controlled comparison from external classifier performance. Neither the folds nor any derived confidence statement is presented as independent external confirmation. The included LaTeX source and vector graphics are editable.
