# Research handoff

The full-row deduplication kept 13,543 of 13,611 records, omitting 68 exact duplicates. No identical feature vector appeared with conflicting labels. The public dataset describes 16 image-derived measurements from seven registered bean varieties. The input ARFF SHA-256 is `b2a4a76a2aedfb8ed415adfc1bfc70b5f202cb00cb72e500766e364c14834014`. [UCI data record](https://doi.org/10.24432/C50S4B)

In the protocol's fixed shuffled five-fold comparison, raw balanced accuracy averaged 71.6174% and training-fold scaled balanced accuracy averaged 93.4556%. The paired gains were +22.23, +22.00, +22.01, +21.45 and +21.50 percentage points. This is the descriptive effect of switching pipelines with the named inputs and split.

Pooling out-of-fold predictions gives the largest raw off-diagonal count for BARBUNYA specimens misclassified as CALI. Those mistakes fell from 460 to 86 among 1,322 BARBUNYA specimens. A residual trade-off is DERMASON misclassified as SIRA, up from 187 to 213 among 3,546 DERMASON specimens. SIRA had the lowest post-scaling recall at 87.41%. These class-level summaries describe held-out predictions from the same study.

Supporting files: [design](01-study-protocol.md), [results](01-results.json), and [analysis source](analyze.py). The study uses one public collection and overlapping training folds, so the folds do not support a confidence interval based on five independent experiments. There is no evidence here on cross-site or camera generalization.
